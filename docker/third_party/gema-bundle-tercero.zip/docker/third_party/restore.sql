--
-- PostgreSQL database dump
--

\restrict hmMJZokFZ1BJ54Ri9RFXh4ec1zTqqsQn3NPTxg4wZg3u0wrzy8T8hDJkT5TXJuc

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.1 (Debian 18.1-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Author; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Author" (
    id_author integer NOT NULL,
    author_name character varying(100) NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Author" OWNER TO postgres;

--
-- Name: Author_id_author_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Author_id_author_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Author_id_author_seq" OWNER TO postgres;

--
-- Name: Author_id_author_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Author_id_author_seq" OWNED BY public."Author".id_author;


--
-- Name: Caste; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Caste" (
    id_caste integer NOT NULL,
    caste_name character varying(50) NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Caste" OWNER TO postgres;

--
-- Name: Caste_id_caste_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Caste_id_caste_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Caste_id_caste_seq" OWNER TO postgres;

--
-- Name: Caste_id_caste_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Caste_id_caste_seq" OWNED BY public."Caste".id_caste;


--
-- Name: ClimateData; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClimateData" (
    id_climate_data integer NOT NULL,
    id_locality integer NOT NULL,
    climate_date date NOT NULL,
    t_min double precision,
    t_max double precision,
    t_med double precision,
    hr_min double precision,
    hr_max double precision,
    hr_med double precision,
    pp_14_days_before double precision,
    pp_30_days_before double precision,
    deleted_at timestamp with time zone
);


ALTER TABLE public."ClimateData" OWNER TO postgres;

--
-- Name: ClimateData_id_climate_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ClimateData_id_climate_data_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ClimateData_id_climate_data_seq" OWNER TO postgres;

--
-- Name: ClimateData_id_climate_data_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ClimateData_id_climate_data_seq" OWNED BY public."ClimateData".id_climate_data;


--
-- Name: Collection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Collection" (
    id_collection integer NOT NULL,
    id_person integer NOT NULL,
    id_preservation_method integer NOT NULL,
    id_trap integer NOT NULL,
    collection_date date NOT NULL,
    trap_number integer,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Collection" OWNER TO postgres;

--
-- Name: Collection_id_collection_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Collection_id_collection_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Collection_id_collection_seq" OWNER TO postgres;

--
-- Name: Collection_id_collection_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Collection_id_collection_seq" OWNED BY public."Collection".id_collection;


--
-- Name: Contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Contact" (
    id_contact integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    message text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone,
    status boolean DEFAULT false NOT NULL,
    id_service integer NOT NULL
);


ALTER TABLE public."Contact" OWNER TO postgres;

--
-- Name: Contact_id_contact_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Contact_id_contact_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Contact_id_contact_seq" OWNER TO postgres;

--
-- Name: Contact_id_contact_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Contact_id_contact_seq" OWNED BY public."Contact".id_contact;


--
-- Name: Country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Country" (
    id_country integer NOT NULL,
    country_name text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Country" OWNER TO postgres;

--
-- Name: Country_id_country_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Country_id_country_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Country_id_country_seq" OWNER TO postgres;

--
-- Name: Country_id_country_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Country_id_country_seq" OWNED BY public."Country".id_country;


--
-- Name: Department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Department" (
    id_department integer NOT NULL,
    id_province integer NOT NULL,
    department_name text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Department" OWNER TO postgres;

--
-- Name: Department_id_department_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Department_id_department_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Department_id_department_seq" OWNER TO postgres;

--
-- Name: Department_id_department_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Department_id_department_seq" OWNED BY public."Department".id_department;


--
-- Name: Environment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Environment" (
    id_environment integer NOT NULL,
    environment_name text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Environment" OWNER TO postgres;

--
-- Name: Environment_id_environment_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Environment_id_environment_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Environment_id_environment_seq" OWNER TO postgres;

--
-- Name: Environment_id_environment_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Environment_id_environment_seq" OWNED BY public."Environment".id_environment;


--
-- Name: Geolocation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Geolocation" (
    id_geolocation integer NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    altitude double precision,
    source_type text NOT NULL,
    tag text,
    ihh double precision,
    distance_to_river double precision,
    id_locality integer NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Geolocation" OWNER TO postgres;

--
-- Name: Geolocation_id_geolocation_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Geolocation_id_geolocation_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Geolocation_id_geolocation_seq" OWNER TO postgres;

--
-- Name: Geolocation_id_geolocation_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Geolocation_id_geolocation_seq" OWNED BY public."Geolocation".id_geolocation;


--
-- Name: Locality; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Locality" (
    id_locality integer NOT NULL,
    id_department integer NOT NULL,
    locality_name text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Locality" OWNER TO postgres;

--
-- Name: Locality_id_locality_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Locality_id_locality_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Locality_id_locality_seq" OWNER TO postgres;

--
-- Name: Locality_id_locality_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Locality_id_locality_seq" OWNED BY public."Locality".id_locality;


--
-- Name: Observation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Observation" (
    id_observation integer NOT NULL,
    id_taxon integer NOT NULL,
    id_collection integer NOT NULL,
    id_geolocation integer NOT NULL,
    id_environment integer,
    id_caste integer,
    id_climate_data integer,
    abundance integer,
    deleted_at timestamp with time zone,
    id_identifier integer,
    identification_date date,
    biology_notes text,
    general_observations text,
    conservation_status character varying(50),
    confirmation_date date,
    id_confirmer integer
);


ALTER TABLE public."Observation" OWNER TO postgres;

--
-- Name: Observation_id_observation_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Observation_id_observation_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Observation_id_observation_seq" OWNER TO postgres;

--
-- Name: Observation_id_observation_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Observation_id_observation_seq" OWNED BY public."Observation".id_observation;


--
-- Name: Person; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Person" (
    id_person integer NOT NULL,
    person_name text NOT NULL,
    person_lastname text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Person" OWNER TO postgres;

--
-- Name: Person_id_person_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Person_id_person_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Person_id_person_seq" OWNER TO postgres;

--
-- Name: Person_id_person_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Person_id_person_seq" OWNED BY public."Person".id_person;


--
-- Name: PreservationMethod; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PreservationMethod" (
    id_preservation_method integer NOT NULL,
    method_name text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."PreservationMethod" OWNER TO postgres;

--
-- Name: PreservationMethod_id_preservation_method_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PreservationMethod_id_preservation_method_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PreservationMethod_id_preservation_method_seq" OWNER TO postgres;

--
-- Name: PreservationMethod_id_preservation_method_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PreservationMethod_id_preservation_method_seq" OWNED BY public."PreservationMethod".id_preservation_method;


--
-- Name: Province; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Province" (
    id_province integer NOT NULL,
    id_country integer NOT NULL,
    province_name text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Province" OWNER TO postgres;

--
-- Name: Province_id_province_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Province_id_province_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Province_id_province_seq" OWNER TO postgres;

--
-- Name: Province_id_province_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Province_id_province_seq" OWNED BY public."Province".id_province;


--
-- Name: Rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Rol" (
    role_id integer NOT NULL,
    name character varying(20) NOT NULL,
    description character varying(255),
    deleted_at timestamp with time zone
);


ALTER TABLE public."Rol" OWNER TO postgres;

--
-- Name: Rol_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Rol_role_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Rol_role_id_seq" OWNER TO postgres;

--
-- Name: Rol_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Rol_role_id_seq" OWNED BY public."Rol".role_id;


--
-- Name: Service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Service" (
    id_service integer NOT NULL,
    service_name character varying(100) NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Service" OWNER TO postgres;

--
-- Name: Service_id_service_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Service_id_service_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Service_id_service_seq" OWNER TO postgres;

--
-- Name: Service_id_service_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Service_id_service_seq" OWNED BY public."Service".id_service;


--
-- Name: Taxon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Taxon" (
    id_taxon integer NOT NULL,
    name text NOT NULL,
    id_taxonomic_level integer NOT NULL,
    parent_id integer,
    id_author integer,
    description_year integer,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Taxon" OWNER TO postgres;

--
-- Name: Taxon_id_taxon_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Taxon_id_taxon_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Taxon_id_taxon_seq" OWNER TO postgres;

--
-- Name: Taxon_id_taxon_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Taxon_id_taxon_seq" OWNED BY public."Taxon".id_taxon;


--
-- Name: TaxonomicLevel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TaxonomicLevel" (
    id_taxonomic_level integer NOT NULL,
    name character varying(50) NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."TaxonomicLevel" OWNER TO postgres;

--
-- Name: TaxonomicLevel_id_taxonomic_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TaxonomicLevel_id_taxonomic_level_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TaxonomicLevel_id_taxonomic_level_seq" OWNER TO postgres;

--
-- Name: TaxonomicLevel_id_taxonomic_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TaxonomicLevel_id_taxonomic_level_seq" OWNED BY public."TaxonomicLevel".id_taxonomic_level;


--
-- Name: Trap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Trap" (
    id_trap integer NOT NULL,
    trap_name text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."Trap" OWNER TO postgres;

--
-- Name: Trap_id_trap_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Trap_id_trap_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Trap_id_trap_seq" OWNER TO postgres;

--
-- Name: Trap_id_trap_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Trap_id_trap_seq" OWNED BY public."Trap".id_trap;


--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    user_id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone,
    role_id integer NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: User_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_user_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_user_id_seq" OWNER TO postgres;

--
-- Name: User_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_user_id_seq" OWNED BY public."User".user_id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: Author id_author; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Author" ALTER COLUMN id_author SET DEFAULT nextval('public."Author_id_author_seq"'::regclass);


--
-- Name: Caste id_caste; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Caste" ALTER COLUMN id_caste SET DEFAULT nextval('public."Caste_id_caste_seq"'::regclass);


--
-- Name: ClimateData id_climate_data; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClimateData" ALTER COLUMN id_climate_data SET DEFAULT nextval('public."ClimateData_id_climate_data_seq"'::regclass);


--
-- Name: Collection id_collection; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Collection" ALTER COLUMN id_collection SET DEFAULT nextval('public."Collection_id_collection_seq"'::regclass);


--
-- Name: Contact id_contact; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact" ALTER COLUMN id_contact SET DEFAULT nextval('public."Contact_id_contact_seq"'::regclass);


--
-- Name: Country id_country; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Country" ALTER COLUMN id_country SET DEFAULT nextval('public."Country_id_country_seq"'::regclass);


--
-- Name: Department id_department; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department" ALTER COLUMN id_department SET DEFAULT nextval('public."Department_id_department_seq"'::regclass);


--
-- Name: Environment id_environment; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Environment" ALTER COLUMN id_environment SET DEFAULT nextval('public."Environment_id_environment_seq"'::regclass);


--
-- Name: Geolocation id_geolocation; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Geolocation" ALTER COLUMN id_geolocation SET DEFAULT nextval('public."Geolocation_id_geolocation_seq"'::regclass);


--
-- Name: Locality id_locality; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Locality" ALTER COLUMN id_locality SET DEFAULT nextval('public."Locality_id_locality_seq"'::regclass);


--
-- Name: Observation id_observation; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Observation" ALTER COLUMN id_observation SET DEFAULT nextval('public."Observation_id_observation_seq"'::regclass);


--
-- Name: Person id_person; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Person" ALTER COLUMN id_person SET DEFAULT nextval('public."Person_id_person_seq"'::regclass);


--
-- Name: PreservationMethod id_preservation_method; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PreservationMethod" ALTER COLUMN id_preservation_method SET DEFAULT nextval('public."PreservationMethod_id_preservation_method_seq"'::regclass);


--
-- Name: Province id_province; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Province" ALTER COLUMN id_province SET DEFAULT nextval('public."Province_id_province_seq"'::regclass);


--
-- Name: Rol role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Rol" ALTER COLUMN role_id SET DEFAULT nextval('public."Rol_role_id_seq"'::regclass);


--
-- Name: Service id_service; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Service" ALTER COLUMN id_service SET DEFAULT nextval('public."Service_id_service_seq"'::regclass);


--
-- Name: Taxon id_taxon; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Taxon" ALTER COLUMN id_taxon SET DEFAULT nextval('public."Taxon_id_taxon_seq"'::regclass);


--
-- Name: TaxonomicLevel id_taxonomic_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaxonomicLevel" ALTER COLUMN id_taxonomic_level SET DEFAULT nextval('public."TaxonomicLevel_id_taxonomic_level_seq"'::regclass);


--
-- Name: Trap id_trap; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Trap" ALTER COLUMN id_trap SET DEFAULT nextval('public."Trap_id_trap_seq"'::regclass);


--
-- Name: User user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN user_id SET DEFAULT nextval('public."User_user_id_seq"'::regclass);


--
-- Data for Name: Author; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Author" (id_author, author_name, deleted_at) FROM stdin;
23	Roger	\N
24	Fabricius	\N
25	Emery	\N
26	Mayr	\N
27	Smith F	\N
28	Olivier	\N
29	Linnaeus	\N
30	Kugler	\N
31	Bolton	\N
32	Guérin-Méneville	\N
33	Brown	\N
34	Spinola	\N
35	Smith	\N
36	Forel	\N
37	Latreille	\N
38	Santschi	\N
39	Gallardo	\N
40	Wilson	\N
41	Kempf	\N
42	Wild	\N
43	Wheeler	\N
44	Della Torres	\N
\.


--
-- Data for Name: Caste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Caste" (id_caste, caste_name, deleted_at) FROM stdin;
17	W	\N
18	Q	\N
19	W;Q	\N
20	Wmi	\N
21	Wma	\N
22	W;Q;M	\N
23	Wmi; Wma; Q	\N
24	WMa	\N
25	R	\N
26	W-1R	\N
27	M	\N
28	W;M	\N
29	Q;M	\N
30	W:Q;M	\N
31	w	\N
\.


--
-- Data for Name: ClimateData; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClimateData" (id_climate_data, id_locality, climate_date, t_min, t_max, t_med, hr_min, hr_max, hr_med, pp_14_days_before, pp_30_days_before, deleted_at) FROM stdin;
20	25	2018-02-14	17.6	35.2	26.4	33.4	99.9	66.65	98.29	163.57	\N
21	28	2018-12-20	24.1	39.7	29.26	34.4	79.6	64.17	38.1	141.47	\N
22	29	2013-11-15	20.1	30.4	25.46	47	66	55.6	100.58	110.99	\N
23	29	2013-11-14	20.1	30.4	25.46	47	66	55.6	100.58	110.99	\N
24	29	2018-03-20	20.1	30.4	25.46	47	66	55.6	100.58	110.99	\N
25	33	2018-12-03	23	34	26.79	49	100	82.04	50.3	139.57	\N
26	35	2018-02-14	14.8	36.5	23.89	38.4	95.9	71.54	3.05	243.84	\N
27	36	2018-02-17	20.2	34.8	26.32	34.1	94.5	75.88	3.05	243.84	\N
28	36	2018-02-14	20.2	34.8	26.32	34.1	94.5	75.88	3.05	243.84	\N
29	37	2015-08-28	19	28	23.67	51.3	100	76.84	42.18	90.86	\N
30	37	2017-10-30	19	28	23.67	51.3	100	76.84	42.18	90.86	\N
31	37	2018-10-30	19	28	23.67	51.3	100	76.84	42.18	90.86	\N
32	37	2019-10-30	19	28	23.67	51.3	100	76.84	42.18	90.86	\N
33	38	2015-11-13	23.2	34.7	29.08	30	68	47.72	48.28	106.94	\N
34	38	2017-10-21	23.2	34.7	29.08	30	68	47.72	48.28	106.94	\N
35	38	2018-10-21	23.2	34.7	29.08	30	68	47.72	48.28	106.94	\N
36	42	2018-03-14	20.1	24.2	21.5	70	79	74.33	3.3	111.68	\N
\.


--
-- Data for Name: Collection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Collection" (id_collection, id_person, id_preservation_method, id_trap, collection_date, trap_number, deleted_at) FROM stdin;
1024	10	4	10	2013-03-24	\N	\N
1025	10	4	10	2013-03-24	\N	\N
1026	10	4	10	2013-03-24	\N	\N
1027	10	4	10	2013-03-24	\N	\N
1028	10	4	10	2013-03-24	\N	\N
1029	10	4	11	2013-03-24	\N	\N
1030	10	4	10	2013-03-24	\N	\N
1031	10	4	10	2013-03-24	\N	\N
1032	10	4	10	2013-03-24	\N	\N
1033	10	4	10	2013-03-24	\N	\N
1034	12	4	10	2015-03-25	\N	\N
1035	10	4	10	2013-03-24	\N	\N
1036	10	4	10	2013-03-24	\N	\N
1037	10	4	10	2009-05-06	\N	\N
1038	10	4	10	2013-03-24	\N	\N
1039	10	5	12	2018-02-14	1	\N
1040	10	5	12	2018-02-14	1	\N
1041	10	5	12	2018-02-14	1	\N
1042	10	5	12	2018-02-14	1	\N
1043	10	5	12	2018-02-14	1	\N
1044	10	5	12	2018-02-14	1	\N
1045	10	5	12	2018-02-14	2	\N
1046	10	5	12	2018-02-14	2	\N
1047	10	5	12	2018-02-14	2	\N
1048	10	5	12	2018-02-14	2	\N
1049	10	5	12	2018-02-14	2	\N
1050	10	5	12	2018-02-14	2	\N
1051	10	5	12	2018-02-14	3	\N
1052	10	5	12	2018-02-14	3	\N
1053	10	5	12	2018-02-14	3	\N
1054	10	5	12	2018-02-14	3	\N
1055	10	5	12	2018-02-14	3	\N
1056	10	5	12	2018-02-14	4	\N
1057	10	5	12	2018-02-14	4	\N
1058	10	5	12	2018-02-14	5	\N
1059	10	5	12	2018-02-14	5	\N
1060	10	5	12	2018-02-14	5	\N
1061	10	5	12	2018-02-14	5	\N
1062	10	5	12	2018-02-14	5	\N
1063	10	5	12	2018-02-14	6	\N
1064	10	5	12	2018-02-14	6	\N
1065	10	5	12	2018-02-14	6	\N
1066	10	5	12	2018-02-14	6	\N
1067	10	5	12	2018-02-14	6	\N
1068	10	5	12	2018-02-14	7	\N
1069	10	5	12	2018-02-14	8	\N
1070	10	5	12	2018-02-14	8	\N
1071	10	5	12	2018-02-14	8	\N
1072	10	5	12	2018-02-14	8	\N
1073	10	5	12	2018-02-14	8	\N
1074	10	5	12	2018-02-14	8	\N
1075	10	5	12	2018-02-14	9	\N
1076	10	5	12	2018-02-14	9	\N
1077	10	5	12	2018-02-14	9	\N
1078	10	5	12	2018-02-14	9	\N
1079	10	5	12	2018-02-14	9	\N
1080	10	5	12	2018-02-14	9	\N
1081	10	5	12	2018-02-14	9	\N
1082	10	5	12	2018-02-14	10	\N
1083	10	5	12	2018-02-14	10	\N
1084	10	5	12	2018-02-14	10	\N
1085	10	5	12	2018-02-14	10	\N
1086	10	5	12	2018-02-14	10	\N
1087	10	5	12	2018-02-14	10	\N
1088	10	5	12	2018-02-14	11	\N
1089	10	5	12	2018-02-14	11	\N
1090	10	5	12	2018-02-14	11	\N
1091	10	5	12	2018-02-14	11	\N
1092	10	5	12	2018-02-14	11	\N
1093	10	5	12	2018-02-14	11	\N
1094	10	5	12	2018-02-14	11	\N
1095	10	5	12	2018-02-14	11	\N
1096	10	5	12	2018-02-14	11	\N
1097	10	5	12	2018-02-14	11	\N
1098	10	5	12	2018-02-14	11	\N
1099	10	5	12	2018-02-14	12	\N
1100	10	5	12	2018-02-14	12	\N
1101	10	5	12	2018-02-14	12	\N
1102	10	5	12	2018-02-14	12	\N
1103	10	5	12	2018-02-14	12	\N
1104	10	5	12	2018-02-14	12	\N
1105	10	5	12	2018-02-14	12	\N
1106	10	5	12	2018-02-14	12	\N
1107	10	5	12	2018-02-14	12	\N
1108	10	5	12	2018-02-14	12	\N
1109	10	5	12	2018-02-14	13	\N
1110	10	5	12	2018-02-14	13	\N
1111	10	5	12	2018-02-14	13	\N
1112	10	5	12	2018-02-14	13	\N
1113	10	5	12	2018-02-14	14	\N
1114	10	5	12	2018-02-14	14	\N
1115	10	5	12	2018-02-14	14	\N
1116	10	5	12	2018-02-14	14	\N
1117	10	5	12	2018-02-14	14	\N
1118	10	5	12	2018-02-14	15	\N
1119	10	5	12	2018-02-14	15	\N
1120	10	5	12	2018-02-14	15	\N
1121	10	5	12	2018-02-14	15	\N
1122	10	5	12	2018-02-14	15	\N
1123	10	5	12	2018-02-14	15	\N
1124	10	5	12	2018-02-14	15	\N
1125	10	5	12	2018-02-14	15	\N
1126	10	5	12	2018-02-14	15	\N
1127	10	5	12	2018-02-14	16	\N
1128	10	5	12	2018-02-14	16	\N
1129	10	5	12	2018-02-14	17	\N
1130	10	5	12	2018-02-14	17	\N
1131	10	5	12	2018-02-14	17	\N
1132	10	5	12	2018-02-14	17	\N
1133	10	5	12	2018-02-14	17	\N
1134	10	5	12	2018-02-14	18	\N
1135	10	5	12	2018-02-14	18	\N
1136	10	5	13	2018-02-14	1	\N
1137	10	5	13	2018-02-14	1	\N
1138	10	5	13	2018-02-14	1	\N
1139	10	5	13	2018-02-14	1	\N
1140	10	5	13	2018-02-14	2	\N
1141	10	5	13	2018-02-14	3	\N
1142	10	5	13	2018-02-14	4	\N
1143	10	5	13	2018-02-14	4	\N
1144	10	5	13	2018-02-14	5	\N
1145	10	5	13	2018-02-14	6	\N
1146	10	5	13	2018-02-14	6	\N
1147	10	5	13	2018-02-14	7	\N
1148	10	5	13	2018-02-14	7	\N
1149	10	5	13	2018-02-14	7	\N
1150	10	5	13	2018-02-14	8	\N
1151	10	5	13	2018-02-14	8	\N
1152	10	5	13	2018-02-14	9	\N
1153	10	5	13	2018-02-14	10	\N
1154	10	5	13	2018-02-14	10	\N
1155	10	5	13	2018-02-14	11	\N
1156	10	5	13	2018-02-14	11	\N
1157	10	5	13	2018-02-14	11	\N
1158	10	5	13	2018-02-14	12	\N
1159	10	5	13	2018-02-14	12	\N
1160	10	5	13	2018-02-14	12	\N
1161	10	5	13	2018-02-14	12	\N
1162	10	5	13	2018-02-14	12	\N
1163	10	5	13	2018-02-14	13	\N
1164	10	5	13	2018-02-14	13	\N
1165	10	5	13	2018-02-14	13	\N
1166	10	5	13	2018-02-14	13	\N
1167	10	5	13	2018-02-14	13	\N
1168	10	5	13	2018-02-14	13	\N
1169	10	5	13	2018-02-14	13	\N
1170	10	5	13	2018-02-14	14	\N
1171	10	5	13	2018-02-14	14	\N
1172	10	5	13	2018-02-14	15	\N
1173	10	5	13	2018-02-14	15	\N
1174	10	5	11	2018-02-14	1	\N
1175	10	5	11	2018-02-14	1	\N
1176	10	5	11	2018-02-14	1	\N
1177	10	5	13	2018-02-14	16	\N
1178	10	5	13	2018-02-14	16	\N
1179	10	5	13	2018-02-14	16	\N
1180	10	5	13	2018-02-14	17	\N
1181	10	5	13	2018-02-14	17	\N
1182	10	5	13	2018-02-14	17	\N
1183	10	5	13	2018-02-14	18	\N
1184	10	5	13	2018-02-14	19	\N
1185	10	5	13	2018-02-14	19	\N
1186	10	5	13	2018-02-14	19	\N
1187	10	5	13	2018-02-14	19	\N
1188	10	5	13	2018-02-14	20	\N
1189	10	5	13	2018-02-14	20	\N
1190	10	5	13	2018-02-14	20	\N
1191	10	5	13	2018-02-14	20	\N
1192	10	5	13	2018-02-14	20	\N
1193	10	5	13	2018-02-14	21	\N
1194	10	5	13	2018-02-14	21	\N
1195	10	5	13	2018-02-14	21	\N
1196	13	4	10	2014-11-20	\N	\N
1197	10	5	12	2018-12-20	1	\N
1198	10	5	12	2018-12-20	1	\N
1199	10	5	12	2018-12-20	1	\N
1200	10	5	12	2018-12-20	2	\N
1201	10	5	12	2018-12-20	2	\N
1202	10	5	13	2018-12-20	1	\N
1203	10	5	13	2018-12-20	1	\N
1204	10	5	13	2018-12-20	2	\N
1205	10	5	13	2018-12-20	3	\N
1206	10	5	13	2018-12-20	3	\N
1207	10	5	13	2018-12-20	4	\N
1208	10	5	13	2018-12-20	5	\N
1209	10	5	13	2018-12-20	5	\N
1210	10	5	13	2018-12-20	5	\N
1211	10	5	13	2018-12-20	6	\N
1212	10	5	13	2018-12-20	6	\N
1213	10	5	13	2018-12-20	7	\N
1214	10	5	13	2018-12-20	7	\N
1215	10	5	13	2018-12-20	8	\N
1216	10	5	13	2018-12-20	8	\N
1217	10	5	13	2018-12-20	8	\N
1218	10	5	13	2018-12-20	8	\N
1219	10	5	13	2018-12-20	9	\N
1220	10	5	13	2018-12-20	9	\N
1221	10	5	13	2018-12-20	9	\N
1222	10	5	13	2018-12-20	10	\N
1223	10	5	13	2018-12-20	10	\N
1224	10	5	13	2018-12-20	10	\N
1225	10	5	13	2018-12-20	11	\N
1226	10	5	13	2018-12-20	12	\N
1227	10	5	13	2018-12-20	13	\N
1228	10	5	13	2018-12-20	14	\N
1229	10	5	13	2018-12-20	14	\N
1230	10	5	13	2018-12-20	14	\N
1231	10	5	13	2018-12-20	14	\N
1232	10	5	13	2018-12-20	15	\N
1233	10	5	13	2018-12-20	15	\N
1234	10	5	13	2018-12-20	15	\N
1235	10	5	13	2018-12-20	16	\N
1236	10	5	13	2018-12-20	16	\N
1237	10	5	13	2018-12-20	16	\N
1238	10	5	13	2018-12-20	17	\N
1239	10	5	13	2018-12-20	17	\N
1240	10	5	13	2018-12-20	17	\N
1241	10	5	13	2018-12-20	17	\N
1242	10	5	13	2018-12-20	18	\N
1243	10	5	13	2018-12-20	18	\N
1244	10	4	13	2013-11-15	1	\N
1245	10	4	13	2013-11-14	\N	\N
1246	10	4	14	2013-11-14	\N	\N
1247	10	4	14	2013-11-14	\N	\N
1248	10	4	10	2013-11-15	\N	\N
1249	10	4	10	2013-11-14	\N	\N
1250	10	4	14	2013-11-15	\N	\N
1251	10	4	13	2013-11-14	\N	\N
1252	10	4	10	2013-11-14	\N	\N
1253	10	4	14	2013-11-15	\N	\N
1254	10	4	14	2013-11-15	\N	\N
1255	10	4	10	2013-11-14	\N	\N
1256	10	4	14	2013-11-15	\N	\N
1257	10	4	13	2013-11-14	\N	\N
1258	10	4	13	2013-11-14	\N	\N
1259	10	4	14	2013-11-15	\N	\N
1260	10	4	10	2013-11-14	\N	\N
1261	10	4	14	2013-11-15	\N	\N
1262	10	4	14	2013-11-15	\N	\N
1263	10	4	14	2013-11-15	\N	\N
1264	10	4	13	2013-11-14	\N	\N
1265	10	4	10	2013-11-14	\N	\N
1266	10	4	14	2013-11-15	\N	\N
1267	10	4	14	2013-11-15	\N	\N
1268	10	5	12	2018-03-20	1	\N
1269	10	5	12	2018-03-20	1	\N
1270	10	5	12	2018-03-20	1	\N
1271	10	5	12	2018-03-20	1	\N
1272	10	5	12	2018-03-20	1	\N
1273	10	5	12	2018-03-20	2	\N
1274	10	5	12	2018-03-20	2	\N
1275	10	5	12	2018-03-20	2	\N
1276	10	5	12	2018-03-20	3	\N
1277	10	5	12	2018-03-20	3	\N
1278	10	5	12	2018-03-20	3	\N
1279	10	5	12	2018-03-20	3	\N
1280	10	5	12	2018-03-20	4	\N
1281	10	5	12	2018-03-20	5	\N
1282	10	5	12	2018-03-20	6	\N
1283	10	5	12	2018-03-20	6	\N
1284	10	5	12	2018-03-20	7	\N
1285	10	5	12	2018-03-20	7	\N
1286	10	5	12	2018-03-20	7	\N
1287	10	5	12	2018-03-20	7	\N
1288	10	5	12	2018-03-20	8	\N
1289	10	5	12	2018-03-20	8	\N
1290	10	5	12	2018-03-20	8	\N
1291	10	5	12	2018-03-20	9	\N
1292	10	5	12	2018-03-20	9	\N
1293	10	5	12	2018-03-20	9	\N
1294	10	5	12	2018-03-20	9	\N
1295	10	5	12	2018-03-20	10	\N
1296	10	5	12	2018-03-20	10	\N
1297	10	5	12	2018-03-20	10	\N
1298	10	5	12	2018-03-20	10	\N
1299	10	5	12	2018-03-20	11	\N
1300	10	5	12	2018-03-20	11	\N
1301	10	5	12	2018-03-20	12	\N
1302	10	5	12	2018-03-20	12	\N
1303	10	5	12	2018-03-20	13	\N
1304	10	5	12	2018-03-20	13	\N
1305	10	5	12	2018-03-20	13	\N
1306	10	5	12	2018-03-20	13	\N
1307	10	5	12	2018-03-20	14	\N
1308	10	5	12	2018-03-20	14	\N
1309	10	5	12	2018-03-20	15	\N
1310	10	5	12	2018-03-20	15	\N
1311	10	5	12	2018-03-20	15	\N
1312	10	5	12	2018-03-20	16	\N
1313	10	5	13	2018-03-20	1	\N
1314	10	5	13	2018-03-20	1	\N
1315	10	5	13	2018-03-20	2	\N
1316	10	5	13	2018-03-20	3	\N
1317	10	5	13	2018-03-20	4	\N
1318	10	5	13	2018-03-20	5	\N
1319	10	5	13	2018-03-20	5	\N
1320	10	5	13	2018-03-20	6	\N
1321	10	5	13	2018-03-20	6	\N
1322	10	5	13	2018-03-20	6	\N
1323	10	5	13	2018-03-20	7	\N
1324	10	5	13	2018-03-20	7	\N
1325	10	5	13	2018-03-20	7	\N
1326	10	5	13	2018-03-20	7	\N
1327	10	5	13	2018-03-20	8	\N
1328	10	5	13	2018-03-20	9	\N
1329	10	5	13	2018-03-20	9	\N
1330	10	5	13	2018-03-20	9	\N
1331	10	5	13	2018-03-20	9	\N
1332	10	5	13	2018-03-20	9	\N
1333	10	5	12	2018-03-20	18	\N
1334	10	5	12	2018-03-20	18	\N
1335	10	5	13	2018-03-20	10	\N
1336	10	5	13	2018-03-20	10	\N
1337	10	5	13	2018-03-20	11	\N
1338	10	5	13	2018-03-20	11	\N
1339	10	5	13	2018-03-20	11	\N
1340	10	5	13	2018-03-20	12	\N
1341	10	5	13	2018-03-20	12	\N
1342	10	5	13	2018-03-20	12	\N
1343	10	5	13	2018-03-20	13	\N
1344	10	5	13	2018-03-20	14	\N
1345	10	5	13	2018-03-20	15	\N
1346	10	5	13	2018-03-20	16	\N
1347	10	5	13	2018-03-20	16	\N
1348	10	5	13	2018-03-20	17	\N
1349	10	5	13	2018-03-20	17	\N
1350	10	5	11	2018-03-20	11	\N
1351	10	5	13	2018-03-20	18	\N
1352	10	5	13	2018-03-20	19	\N
1353	10	5	13	2018-03-20	20	\N
1354	10	5	13	2018-03-20	20	\N
1355	10	5	13	2018-03-20	20	\N
1356	10	5	13	2018-03-20	21	\N
1357	10	5	13	2018-03-20	21	\N
1358	10	5	13	2018-03-20	21	\N
1359	10	5	13	2018-03-20	22	\N
1360	10	5	13	2018-03-20	22	\N
1361	10	5	13	2018-03-20	22	\N
1362	10	5	11	2018-03-20	1	\N
1363	10	5	13	2018-03-20	23	\N
1364	10	5	13	2018-03-20	23	\N
1365	10	5	13	2018-03-20	23	\N
1366	10	5	13	2018-03-20	24	\N
1367	10	5	13	2018-03-20	25	\N
1368	10	5	13	2018-03-20	25	\N
1369	10	5	13	2018-03-20	25	\N
1370	10	5	13	2018-03-20	25	\N
1371	10	5	13	2018-03-20	25	\N
1372	10	5	13	2018-03-20	26	\N
1373	10	5	13	2018-03-20	27	\N
1374	10	5	13	2018-03-20	27	\N
1375	10	5	13	2018-03-20	27	\N
1376	10	5	13	2018-03-20	28	\N
1377	10	4	10	2013-10-16	\N	\N
1378	10	4	15	2013-10-16	\N	\N
1379	10	4	10	2013-10-16	\N	\N
1380	10	4	14	2013-10-14	\N	\N
1381	10	4	10	2013-10-16	\N	\N
1382	10	4	10	2013-10-16	\N	\N
1383	10	4	14	2013-10-14	\N	\N
1384	10	4	10	2013-10-16	\N	\N
1385	10	4	10	2013-10-16	\N	\N
1386	10	4	15	2013-10-16	\N	\N
1387	10	4	10	2013-10-16	\N	\N
1388	10	4	14	2013-10-14	\N	\N
1389	10	4	10	2013-10-16	\N	\N
1390	10	4	10	2013-10-16	\N	\N
1391	10	4	10	2013-10-16	\N	\N
1392	10	4	10	2013-10-16	\N	\N
1393	10	4	10	2013-10-16	\N	\N
1394	10	4	10	2013-10-16	\N	\N
1395	10	4	10	2013-10-16	\N	\N
1396	10	4	10	2013-10-16	\N	\N
1397	10	4	10	2013-10-16	\N	\N
1398	10	4	10	2013-10-16	\N	\N
1399	10	4	10	2013-10-16	\N	\N
1400	14	4	10	2011-10-26	1	\N
1401	14	4	10	2011-10-26	4	\N
1402	14	5	10	2011-10-26	5	\N
1403	14	5	10	2011-10-26	3	\N
1404	14	5	10	2011-10-26	6	\N
1405	14	5	10	2011-10-26	7	\N
1406	14	5	10	2011-10-26	8	\N
1407	14	5	10	2011-10-26	9	\N
1408	14	5	10	2011-10-26	10	\N
1409	14	5	10	2011-10-26	11	\N
1410	14	5	10	2011-10-26	12	\N
1411	14	5	10	2011-10-26	13	\N
1412	14	5	10	2011-10-26	14	\N
1413	14	5	10	2011-10-26	15	\N
1414	14	5	10	2011-10-26	16	\N
1415	14	5	10	2011-10-26	17	\N
1416	13	4	10	2013-11-28	\N	\N
1417	10	5	12	2018-12-03	1	\N
1418	10	5	12	2018-12-03	1	\N
1419	10	5	12	2018-12-03	2	\N
1420	10	5	12	2018-12-03	2	\N
1421	10	5	12	2018-12-03	2	\N
1422	10	5	13	2018-12-03	1	\N
1423	10	5	12	2018-12-03	3	\N
1424	10	5	12	2018-12-03	3	\N
1425	10	5	12	2018-12-03	3	\N
1426	10	5	12	2018-12-03	4	\N
1427	10	5	12	2018-12-03	4	\N
1428	10	5	12	2018-12-03	5	\N
1429	10	5	12	2018-12-03	5	\N
1430	10	5	12	2018-12-03	6	\N
1431	10	5	12	2018-12-03	6	\N
1432	10	5	12	2018-12-03	6	\N
1433	10	5	11	2018-12-03	6	\N
1434	10	5	12	2018-12-03	6	\N
1435	10	5	12	2018-12-03	6	\N
1436	10	5	12	2018-12-03	7	\N
1437	10	5	12	2018-12-03	7	\N
1438	10	5	12	2018-12-03	7	\N
1439	10	5	12	2018-12-03	7	\N
1440	10	5	12	2018-12-03	8	\N
1441	10	5	12	2018-12-03	8	\N
1442	10	5	12	2018-12-03	9	\N
1443	10	5	12	2018-12-03	9	\N
1444	10	5	12	2018-12-03	10	\N
1445	10	5	12	2018-12-03	10	\N
1446	10	5	12	2018-12-03	10	\N
1447	10	5	12	2018-12-03	11	\N
1448	10	5	12	2018-12-03	11	\N
1449	10	5	11	2018-12-03	2	\N
1450	10	5	12	2018-12-03	11	\N
1451	10	5	12	2018-12-03	12	\N
1452	10	5	12	2018-12-03	12	\N
1453	10	5	12	2018-12-03	12	\N
1454	10	5	12	2018-12-03	12	\N
1455	10	5	12	2018-12-03	12	\N
1456	10	5	12	2018-12-03	13	\N
1457	10	5	12	2018-12-03	13	\N
1458	10	5	11	2018-12-03	3	\N
1459	10	5	12	2018-12-03	13	\N
1460	10	5	12	2018-12-03	13	\N
1461	10	5	12	2018-12-03	13	\N
1462	10	5	12	2018-12-03	13	\N
1463	10	5	11	2018-12-03	4	\N
1464	10	5	12	2018-12-03	14	\N
1465	10	5	12	2018-12-03	14	\N
1466	10	5	12	2018-12-03	14	\N
1467	10	5	12	2018-12-03	15	\N
1468	10	5	12	2018-12-03	15	\N
1469	10	5	12	2018-12-03	15	\N
1470	10	5	12	2018-12-03	16	\N
1471	10	5	12	2018-12-03	16	\N
1472	10	5	12	2018-12-03	16	\N
1473	10	5	12	2018-12-03	16	\N
1474	10	5	12	2018-12-03	16	\N
1475	10	5	12	2018-12-03	16	\N
1476	10	5	12	2018-12-03	16	\N
1477	10	5	12	2018-12-03	17	\N
1478	10	5	12	2018-12-03	17	\N
1479	10	5	12	2018-12-03	17	\N
1480	10	5	12	2018-12-03	18	\N
1481	10	5	12	2018-12-03	18	\N
1482	10	5	12	2018-12-03	2	\N
1483	10	5	12	2018-12-03	2	\N
1484	14	4	11	2009-01-07	1	\N
1485	10	5	13	2018-02-14	1	\N
1486	10	5	13	2018-02-14	2	\N
1487	10	5	13	2018-02-14	2	\N
1488	10	5	13	2018-02-14	2	\N
1489	10	5	13	2018-02-14	3	\N
1490	10	5	13	2018-02-14	3	\N
1491	10	5	13	2018-02-14	3	\N
1492	10	5	13	2018-02-14	4	\N
1493	10	5	13	2018-02-14	4	\N
1494	10	5	13	2018-02-14	4	\N
1495	10	5	13	2018-02-14	4	\N
1496	10	5	13	2018-02-14	4	\N
1497	10	5	13	2018-02-14	4	\N
1498	10	4	13	2018-02-14	2	\N
1499	10	5	13	2018-02-14	3	\N
1500	10	5	13	2018-02-14	12	\N
1501	10	5	13	2018-02-14	13	\N
1502	10	5	13	2018-02-14	5	\N
1503	10	5	13	2018-02-14	6	\N
1504	10	5	13	2018-02-14	7	\N
1505	10	5	13	2018-02-14	7	\N
1506	10	5	13	2018-02-14	7	\N
1507	10	5	13	2018-02-14	7	\N
1508	10	5	13	2018-02-14	8	\N
1509	10	5	13	2018-02-14	8	\N
1510	10	5	13	2018-02-14	5	\N
1511	10	5	13	2018-02-14	5	\N
1512	10	5	13	2018-02-14	5	\N
1513	10	5	13	2018-02-14	5	\N
1514	10	5	13	2018-02-14	6	\N
1515	10	5	13	2018-02-14	6	\N
1516	10	5	13	2018-02-14	6	\N
1517	10	5	13	2018-02-14	9	\N
1518	10	5	13	2018-02-14	9	\N
1519	10	5	13	2018-02-14	10	\N
1520	10	5	13	2018-02-14	11	\N
1521	10	5	13	2018-02-14	11	\N
1522	10	5	13	2018-02-14	11	\N
1523	10	5	13	2018-02-14	11	\N
1524	10	5	12	2018-02-14	1	\N
1525	10	5	12	2018-02-14	1	\N
1526	10	5	12	2018-02-14	1	\N
1527	10	5	12	2018-02-14	1	\N
1528	10	5	12	2018-02-14	2	\N
1529	10	5	12	2018-02-14	2	\N
1530	10	5	12	2018-02-14	3	\N
1531	10	5	12	2018-02-14	3	\N
1532	10	5	12	2018-02-14	3	\N
1533	10	5	12	2018-02-14	4	\N
1534	10	5	12	2018-02-14	4	\N
1535	10	5	12	2018-02-14	4	\N
1536	10	5	12	2018-02-14	4	\N
1537	10	5	12	2018-02-14	5	\N
1538	10	5	12	2018-02-14	5	\N
1539	10	5	12	2018-02-14	5	\N
1540	10	5	12	2018-02-14	5	\N
1541	10	5	12	2018-02-14	5	\N
1542	10	5	12	2018-02-14	6	\N
1543	10	5	12	2018-02-14	6	\N
1544	10	5	12	2018-02-14	7	\N
1545	10	5	12	2018-02-14	7	\N
1546	10	5	12	2018-02-14	7	\N
1547	10	5	12	2018-02-14	7	\N
1548	10	5	12	2018-02-14	8	\N
1549	10	5	12	2018-02-14	8	\N
1550	10	5	12	2018-02-14	8	\N
1551	10	5	12	2018-02-14	8	\N
1552	10	5	12	2018-02-14	8	\N
1553	10	5	12	2018-02-14	9	\N
1554	10	5	12	2018-02-14	9	\N
1555	10	5	12	2018-02-14	9	\N
1556	10	5	12	2018-02-14	9	\N
1557	10	5	12	2018-02-14	9	\N
1558	10	5	12	2018-02-14	9	\N
1559	10	5	12	2018-02-14	10	\N
1560	10	5	12	2018-02-14	10	\N
1561	10	5	12	2018-02-14	10	\N
1562	10	5	12	2018-02-14	10	\N
1563	10	5	12	2018-02-14	10	\N
1564	10	4	12	2018-02-14	11	\N
1565	10	5	12	2018-02-14	11	\N
1566	10	5	12	2018-02-14	11	\N
1567	10	5	12	2018-02-14	11	\N
1568	10	5	12	2018-02-14	11	\N
1569	10	5	12	2018-02-14	12	\N
1570	10	5	12	2018-02-14	12	\N
1571	10	5	12	2018-02-14	12	\N
1572	10	5	12	2018-02-14	12	\N
1573	10	5	12	2018-02-14	12	\N
1574	10	5	12	2018-02-14	13	\N
1575	10	5	12	2018-02-14	13	\N
1576	10	5	12	2018-02-14	13	\N
1577	10	5	12	2018-02-14	13	\N
1578	10	5	12	2018-02-14	14	\N
1579	10	5	12	2018-02-14	14	\N
1580	10	5	12	2018-02-14	14	\N
1581	10	5	12	2018-02-14	14	\N
1582	10	5	12	2018-02-14	14	\N
1583	10	5	12	2018-02-14	14	\N
1584	10	5	12	2018-02-14	15	\N
1585	10	5	12	2018-02-14	15	\N
1586	10	5	12	2018-02-14	15	\N
1587	10	5	12	2018-02-14	16	\N
1588	10	5	12	2018-02-14	16	\N
1589	10	5	12	2018-02-14	17	\N
1590	10	5	12	2018-02-14	17	\N
1591	10	5	12	2018-02-14	17	\N
1592	10	5	12	2018-02-14	17	\N
1593	10	5	12	2018-02-14	17	\N
1594	10	5	12	2018-02-14	18	\N
1595	10	5	12	2018-02-14	18	\N
1596	10	5	12	2018-02-14	18	\N
1597	10	5	12	2018-02-14	18	\N
1598	10	5	12	2018-02-14	19	\N
1599	10	5	12	2018-02-14	19	\N
1600	10	5	12	2018-02-14	19	\N
1601	10	5	12	2018-02-14	20	\N
1602	10	5	12	2018-02-14	20	\N
1603	10	5	12	2018-02-14	21	\N
1604	10	5	12	2018-02-14	21	\N
1605	10	5	12	2018-02-14	22	\N
1606	10	5	12	2018-02-14	22	\N
1607	10	5	12	2018-02-14	23	\N
1608	10	5	12	2018-02-14	23	\N
1609	10	5	12	2018-02-14	24	\N
1610	10	5	12	2018-02-14	25	\N
1611	10	5	12	2018-02-14	25	\N
1612	10	5	12	2018-02-14	26	\N
1613	10	5	12	2018-02-14	26	\N
1614	10	5	12	2018-02-14	27	\N
1615	10	5	12	2018-02-14	27	\N
1616	10	5	12	2018-02-14	27	\N
1617	10	5	11	2018-02-17	1	\N
1618	10	5	13	2018-02-14	1	\N
1619	10	5	13	2018-02-14	1	\N
1620	10	5	13	2018-02-14	1	\N
1621	10	5	13	2018-02-14	1	\N
1622	10	5	13	2018-02-14	2	\N
1623	10	5	13	2018-02-14	2	\N
1624	10	5	13	2018-02-14	2	\N
1625	10	5	13	2018-02-14	3	\N
1626	10	5	13	2018-02-14	4	\N
1627	10	5	13	2018-02-14	4	\N
1628	10	5	13	2018-02-14	5	\N
1629	10	5	13	2018-02-14	6	\N
1630	10	5	13	2018-02-14	6	\N
1631	10	5	13	2018-02-14	6	\N
1632	10	5	13	2018-02-14	7	\N
1633	10	5	13	2018-02-14	7	\N
1634	10	5	13	2018-02-14	8	\N
1635	10	5	13	2018-02-14	8	\N
1636	10	5	13	2018-02-14	9	\N
1637	10	5	13	2018-02-14	10	\N
1638	10	5	13	2018-02-14	10	\N
1639	10	5	13	2018-02-14	10	\N
1640	10	5	13	2018-02-14	10	\N
1641	10	5	13	2018-02-14	10	\N
1642	10	5	13	2018-02-14	11	\N
1643	10	5	13	2018-02-14	12	\N
1644	10	5	13	2018-02-14	13	\N
1645	10	5	13	2018-02-14	13	\N
1646	10	5	13	2018-02-14	13	\N
1647	10	5	13	2018-02-14	14	\N
1648	10	5	13	2018-02-14	14	\N
1649	10	5	13	2018-02-14	15	\N
1650	10	5	13	2018-02-14	15	\N
1651	10	5	13	2018-02-14	15	\N
1652	10	5	13	2018-02-14	16	\N
1653	10	5	13	2018-02-14	16	\N
1654	10	5	13	2018-02-14	17	\N
1655	10	5	13	2018-02-14	17	\N
1656	10	5	13	2018-02-14	18	\N
1657	10	5	13	2018-02-14	18	\N
1658	10	5	13	2018-02-14	19	\N
1659	10	5	13	2018-02-14	19	\N
1660	10	5	13	2018-02-14	21	\N
1661	10	5	13	2018-02-14	20	\N
1662	10	5	13	2018-02-14	21	\N
1663	10	5	11	2018-02-14	2	\N
1664	10	5	13	2018-02-14	22	\N
1665	10	5	11	2018-02-14	1	\N
1666	10	5	11	2018-02-14	1	\N
1667	10	5	12	2018-02-14	1	\N
1668	10	5	12	2018-02-14	1	\N
1669	10	5	12	2018-02-14	1	\N
1670	10	5	12	2018-02-14	1	\N
1671	10	5	12	2018-02-14	2	\N
1672	10	5	12	2018-02-14	2	\N
1673	10	5	12	2018-02-14	2	\N
1674	10	5	12	2018-02-14	3	\N
1675	10	5	12	2018-02-14	4	\N
1676	10	5	12	2018-02-14	4	\N
1677	10	5	12	2018-02-14	4	\N
1678	10	5	12	2018-02-14	4	\N
1679	10	5	12	2018-02-14	4	\N
1680	10	5	12	2018-02-14	5	\N
1681	10	5	12	2018-02-14	5	\N
1682	10	5	12	2018-02-14	6	\N
1683	10	5	12	2018-02-14	6	\N
1684	10	5	12	2018-02-14	7	\N
1685	10	5	12	2018-02-14	8	\N
1686	10	5	12	2018-02-14	8	\N
1687	10	5	12	2018-02-14	8	\N
1688	10	5	12	2018-02-14	9	\N
1689	10	5	12	2018-02-14	9	\N
1690	10	5	12	2018-02-14	10	\N
1691	10	5	12	2018-02-14	10	\N
1692	10	5	12	2018-02-14	11	\N
1693	10	5	12	2018-02-14	12	\N
1694	10	5	12	2018-02-14	13	\N
1695	10	5	12	2018-02-14	13	\N
1696	10	5	12	2018-02-14	13	\N
1697	10	5	12	2018-02-14	14	\N
1698	10	5	12	2018-02-14	14	\N
1699	10	5	12	2018-02-14	14	\N
1700	10	5	12	2018-02-14	14	\N
1701	10	5	12	2018-02-14	15	\N
1702	10	5	12	2018-02-14	15	\N
1703	10	5	12	2018-02-14	16	\N
1704	10	5	12	2018-02-14	17	\N
1705	10	5	12	2018-02-14	18	\N
1706	10	5	12	2018-02-14	18	\N
1707	10	5	12	2018-02-14	18	\N
1708	10	5	12	2018-02-14	18	\N
1709	10	5	12	2018-02-14	18	\N
1710	10	5	12	2018-02-14	19	\N
1711	10	5	12	2018-02-14	19	\N
1712	10	5	12	2018-02-14	19	\N
1713	10	5	12	2018-02-14	20	\N
1714	10	5	12	2018-02-14	21	\N
1715	10	5	12	2018-02-14	21	\N
1716	10	5	12	2018-02-14	22	\N
1717	10	5	12	2018-02-14	22	\N
1718	10	4	12	2015-08-28	\N	\N
1719	10	5	13	2017-10-30	1	\N
1720	10	5	13	2017-10-30	1	\N
1721	10	5	13	2017-10-30	2	\N
1722	10	5	13	2017-10-30	3	\N
1723	10	5	13	2017-10-30	4	\N
1724	10	5	13	2017-10-30	5	\N
1725	10	5	13	2017-10-30	5	\N
1726	10	5	13	2017-10-30	5	\N
1727	10	5	13	2017-10-30	6	\N
1728	10	5	13	2017-10-30	7	\N
1729	10	5	13	2017-10-30	8	\N
1730	10	5	13	2017-10-30	9	\N
1731	10	5	13	2017-10-30	9	\N
1732	10	5	13	2017-10-30	9	\N
1733	10	5	13	2017-10-30	9	\N
1734	10	5	13	2017-10-30	9	\N
1735	10	5	13	2017-10-30	9	\N
1736	10	5	13	2017-10-30	10	\N
1737	10	5	13	2017-10-30	11	\N
1738	10	5	13	2017-10-30	11	\N
1739	10	5	13	2017-10-30	12	\N
1740	10	5	13	2017-10-30	13	\N
1741	10	5	13	2017-10-30	13	\N
1742	10	5	13	2017-10-30	13	\N
1743	10	5	13	2017-10-30	13	\N
1744	10	5	13	2017-10-30	14	\N
1745	10	5	13	2017-10-30	14	\N
1746	10	5	13	2017-10-30	15	\N
1747	10	5	13	2017-10-30	15	\N
1748	10	5	13	2017-10-30	16	\N
1749	10	5	13	2017-10-30	16	\N
1750	10	5	13	2017-10-30	16	\N
1751	10	5	13	2017-10-30	17	\N
1752	10	5	13	2017-10-30	18	\N
1753	10	5	13	2017-10-30	18	\N
1754	10	5	13	2017-10-30	18	\N
1755	10	5	13	2017-10-30	19	\N
1756	10	5	13	2017-10-30	19	\N
1757	10	5	13	2017-10-30	20	\N
1758	10	5	13	2017-10-30	21	\N
1759	10	5	13	2017-10-30	21	\N
1760	10	5	13	2017-10-30	21	\N
1761	10	5	13	2017-10-30	21	\N
1762	10	5	13	2017-10-30	22	\N
1763	10	5	13	2017-10-30	23	\N
1764	10	5	13	2017-10-30	24	\N
1765	10	5	13	2017-10-30	24	\N
1766	10	5	13	2017-10-30	24	\N
1767	10	5	13	2017-10-30	25	\N
1768	10	5	13	2017-10-30	26	\N
1769	10	5	13	2017-10-30	26	\N
1770	10	5	13	2017-10-30	26	\N
1771	10	5	13	2017-10-30	26	\N
1772	10	5	13	2017-10-30	26	\N
1773	10	5	13	2017-10-30	27	\N
1774	10	5	13	2017-10-30	27	\N
1775	10	5	13	2017-10-30	27	\N
1776	10	5	13	2017-10-30	27	\N
1777	10	5	13	2017-10-30	28	\N
1778	10	5	13	2017-10-30	28	\N
1779	10	5	13	2017-10-30	29	\N
1780	10	5	13	2017-10-30	29	\N
1781	10	5	13	2017-10-30	30	\N
1782	10	5	13	2017-10-30	30	\N
1783	10	5	13	2017-10-30	30	\N
1784	10	5	13	2017-10-30	31	\N
1785	10	5	13	2017-10-30	31	\N
1786	10	5	13	2018-10-30	32	\N
1787	10	5	13	2019-10-30	33	\N
1788	10	5	13	2017-10-30	34	\N
1789	10	5	13	2017-10-30	34	\N
1790	10	5	12	2017-10-30	1	\N
1791	10	5	12	2017-10-30	1	\N
1792	10	5	12	2017-10-30	1	\N
1793	10	5	12	2017-10-30	2	\N
1794	10	5	12	2017-10-30	2	\N
1795	10	5	12	2017-10-30	3	\N
1796	10	5	12	2017-10-30	3	\N
1797	10	5	12	2017-10-30	3	\N
1798	10	5	12	2017-10-30	4	\N
1799	10	5	12	2017-10-30	4	\N
1800	10	5	12	2017-10-30	5	\N
1801	10	5	12	2017-10-30	5	\N
1802	10	5	12	2017-10-30	5	\N
1803	10	5	12	2017-10-30	6	\N
1804	10	5	12	2017-10-30	6	\N
1805	10	5	12	2017-10-30	7	\N
1806	10	5	12	2017-10-30	8	\N
1807	10	5	12	2017-10-30	8	\N
1808	10	5	12	2017-10-30	9	\N
1809	10	5	12	2017-10-30	9	\N
1810	10	5	12	2017-10-30	10	\N
1811	10	5	12	2017-10-30	11	\N
1812	10	5	12	2017-10-30	11	\N
1813	10	5	12	2017-10-30	12	\N
1814	10	5	12	2017-10-30	12	\N
1815	10	5	12	2017-10-30	13	\N
1816	10	5	12	2017-10-30	13	\N
1817	10	5	12	2017-10-30	13	\N
1818	10	5	12	2017-10-30	14	\N
1819	10	5	12	2017-10-30	14	\N
1820	10	5	12	2017-10-30	15	\N
1821	10	5	12	2017-10-30	15	\N
1822	10	5	12	2017-10-30	16	\N
1823	10	5	12	2017-10-30	16	\N
1824	10	5	12	2017-10-30	17	\N
1825	10	5	12	2017-10-30	17	\N
1826	10	5	12	2017-10-30	17	\N
1827	10	5	12	2017-10-30	18	\N
1828	10	5	12	2017-10-30	18	\N
1829	10	5	12	2017-10-30	18	\N
1830	10	5	12	2017-10-30	19	\N
1831	10	5	12	2017-10-30	19	\N
1832	10	5	12	2017-10-30	20	\N
1833	10	5	12	2017-10-30	20	\N
1834	10	5	12	2017-10-30	20	\N
1835	10	5	12	2017-10-30	21	\N
1836	10	5	12	2017-10-30	21	\N
1837	10	5	12	2017-10-30	22	\N
1838	10	5	12	2017-10-30	22	\N
1839	10	5	12	2017-10-30	22	\N
1840	10	5	12	2017-10-30	23	\N
1841	10	5	12	2017-10-30	23	\N
1842	10	5	12	2017-10-30	24	\N
1843	10	5	12	2017-10-30	25	\N
1844	10	4	12	2015-11-13	8	\N
1845	10	4	12	2015-11-13	\N	\N
1846	10	5	13	2017-10-21	1	\N
1847	10	5	13	2017-10-21	1	\N
1848	10	5	13	2017-10-21	1	\N
1849	10	5	13	2017-10-21	2	\N
1850	10	5	13	2017-10-21	3	\N
1851	10	5	13	2017-10-21	4	\N
1852	10	5	13	2017-10-21	4	\N
1853	10	5	13	2017-10-21	4	\N
1854	10	5	13	2017-10-21	4	\N
1855	10	5	12	2017-10-21	4	\N
1856	10	5	13	2017-10-21	5	\N
1857	10	5	13	2017-10-21	5	\N
1858	10	5	13	2017-10-21	5	\N
1859	10	5	13	2017-10-21	5	\N
1860	10	5	13	2017-10-21	6	\N
1861	10	5	13	2017-10-21	6	\N
1862	10	5	13	2017-10-21	6	\N
1863	10	5	13	2017-10-21	7	\N
1864	10	5	13	2017-10-21	7	\N
1865	10	5	13	2017-10-21	7	\N
1866	10	5	13	2017-10-21	8	\N
1867	10	5	13	2017-10-21	8	\N
1868	10	5	13	2017-10-21	8	\N
1869	10	5	13	2017-10-21	9	\N
1870	10	5	13	2017-10-21	9	\N
1871	10	5	13	2017-10-21	10	\N
1872	10	5	13	2017-10-21	10	\N
1873	10	5	13	2017-10-21	10	\N
1874	10	5	13	2017-10-21	11	\N
1875	10	5	13	2017-10-21	11	\N
1876	10	5	13	2017-10-21	12	\N
1877	10	5	13	2017-10-21	12	\N
1878	10	5	13	2017-10-21	13	\N
1879	10	5	13	2017-10-21	13	\N
1880	10	5	13	2017-10-21	14	\N
1881	10	5	13	2017-10-21	14	\N
1882	10	5	13	2017-10-21	15	\N
1883	10	5	13	2017-10-21	15	\N
1884	10	5	13	2017-10-21	15	\N
1885	10	5	13	2017-10-21	15	\N
1886	10	5	13	2017-10-21	15	\N
1887	10	5	13	2017-10-21	16	\N
1888	10	5	13	2017-10-21	17	\N
1889	10	5	13	2017-10-21	18	\N
1890	10	5	13	2017-10-21	19	\N
1891	10	5	13	2017-10-21	19	\N
1892	10	5	13	2017-10-21	19	\N
1893	10	5	13	2017-10-21	19	\N
1894	10	5	13	2017-10-21	19	\N
1895	10	5	13	2017-10-21	20	\N
1896	10	5	13	2017-10-21	20	\N
1897	10	5	13	2017-10-21	20	\N
1898	10	5	13	2017-10-21	20	\N
1899	10	5	12	2017-10-21	1	\N
1900	10	5	12	2017-10-21	1	\N
1901	10	5	12	2017-10-21	1	\N
1902	10	5	12	2017-10-21	2	\N
1903	10	5	12	2017-10-21	3	\N
1904	10	5	12	2017-10-21	4	\N
1905	10	5	12	2017-10-21	5	\N
1906	10	5	12	2017-10-21	5	\N
1907	10	5	12	2017-10-21	5	\N
1908	10	5	12	2017-10-21	5	\N
1909	10	5	12	2017-10-21	6	\N
1910	10	5	12	2017-10-21	6	\N
1911	10	5	11	2017-10-21	1	\N
1912	10	5	11	2017-10-21	2	\N
1913	10	5	11	2017-10-21	3	\N
1914	10	5	12	2017-10-21	7	\N
1915	10	5	12	2017-10-21	7	\N
1916	10	5	11	2017-10-21	4	\N
1917	10	5	12	2017-10-21	8	\N
1918	10	5	12	2018-10-21	8	\N
1919	10	5	12	2018-10-21	8	\N
1920	10	5	12	2017-10-21	8	\N
1921	10	5	12	2017-10-21	8	\N
1922	10	5	12	2017-10-21	8	\N
1923	10	5	12	2017-10-21	8	\N
1924	10	5	12	2017-10-21	8	\N
1925	10	5	12	2017-10-21	8	\N
1926	10	5	12	2017-10-21	9	\N
1927	10	5	12	2017-10-21	9	\N
1928	10	5	12	2017-10-21	10	\N
1929	10	5	12	2017-10-21	10	\N
1930	10	5	12	2017-10-21	11	\N
1931	10	5	12	2017-10-21	11	\N
1932	10	5	12	2017-10-21	12	\N
1933	10	5	12	2017-10-21	12	\N
1934	10	5	12	2017-10-21	12	\N
1935	10	5	12	2017-10-21	13	\N
1936	10	5	12	2017-10-21	13	\N
1937	10	5	12	2017-10-21	13	\N
1938	10	5	12	2017-10-21	13	\N
1939	10	5	12	2017-10-21	13	\N
1940	10	5	12	2017-10-21	14	\N
1941	10	5	12	2017-10-21	14	\N
1942	10	5	12	2017-10-21	14	\N
1943	10	5	12	2017-10-21	15	\N
1944	10	5	12	2017-10-21	15	\N
1945	10	5	12	2017-10-21	15	\N
1946	10	5	12	2017-10-21	15	\N
1947	10	5	12	2017-10-21	15	\N
1948	10	5	12	2017-10-21	15	\N
1949	10	5	12	2017-10-21	15	\N
1950	10	5	12	2017-10-21	15	\N
1951	10	5	12	2017-10-21	16	\N
1952	10	5	12	2017-10-21	16	\N
1953	10	5	12	2017-10-21	16	\N
1954	10	5	12	2017-10-21	16	\N
1955	10	5	12	2017-10-21	16	\N
1956	10	5	12	2017-10-21	16	\N
1957	10	5	12	2017-10-21	17	\N
1958	10	5	12	2017-10-21	17	\N
1959	10	5	12	2017-10-21	17	\N
1960	10	5	12	2017-10-21	17	\N
1961	10	5	12	2017-10-21	18	\N
1962	10	5	12	2017-10-21	18	\N
1963	10	5	12	2017-10-21	19	\N
1964	10	5	12	2017-10-21	19	\N
1965	10	5	12	2017-10-21	20	\N
1966	10	5	12	2017-10-21	20	\N
1967	10	5	12	2017-10-21	21	\N
1968	10	5	12	2017-10-21	22	\N
1969	10	5	12	2017-10-21	23	\N
1970	10	5	12	2017-10-21	24	\N
1971	10	5	11	2017-10-21	5	\N
1972	10	5	11	2017-10-21	5	\N
1973	10	5	11	2017-10-21	5	\N
1974	10	5	12	2017-10-21	24	\N
1975	10	5	12	2017-10-21	24	\N
1976	10	5	11	2017-10-21	24	\N
1977	10	5	11	2017-10-21	25	\N
1978	10	5	12	2017-10-21	25	\N
1979	10	5	12	2017-10-21	25	\N
1980	10	5	12	2017-10-21	26	\N
1981	10	5	12	2017-10-21	26	\N
1982	10	5	12	2017-10-21	27	\N
1983	10	5	12	2017-10-21	28	\N
1984	10	5	12	2017-10-21	28	\N
1985	10	5	12	2017-10-21	28	\N
1986	10	5	11	2017-10-21	6	\N
1987	10	5	12	2017-10-21	29	\N
1988	10	5	12	2017-10-21	29	\N
1989	10	5	11	2017-10-21	7	\N
1990	10	5	11	2017-10-21	7	\N
1991	10	5	12	2017-10-21	30	\N
1992	10	5	12	2018-03-14	1	\N
1993	10	5	12	2018-03-14	1	\N
1994	10	5	11	2018-03-14	1	\N
1995	10	5	11	2018-03-14	1	\N
1996	10	5	11	2018-03-14	1	\N
1997	10	5	12	2018-03-14	2	\N
1998	10	5	12	2018-03-14	2	\N
1999	10	5	12	2018-03-14	2	\N
2000	10	5	12	2018-03-14	2	\N
2001	10	5	12	2018-03-14	2	\N
2002	10	5	12	2018-03-14	2	\N
2003	10	5	12	2018-03-14	3	\N
2004	10	5	12	2018-03-14	3	\N
2005	10	5	12	2018-03-14	4	\N
2006	10	5	12	2018-03-14	4	\N
2007	10	5	12	2018-03-14	5	\N
2008	10	5	12	2018-03-14	5	\N
2009	10	5	12	2018-03-14	5	\N
2010	10	5	12	2018-03-14	5	\N
2011	10	5	12	2018-03-14	6	\N
2012	10	5	12	2018-03-14	6	\N
2013	10	5	12	2018-03-14	6	\N
2014	10	5	12	2018-03-14	6	\N
2015	10	5	12	2018-03-14	6	\N
2016	10	5	13	2018-03-14	1	\N
2017	10	5	13	2018-03-14	1	\N
2018	10	5	13	2018-03-14	2	\N
2019	10	5	13	2018-03-14	2	\N
2020	10	5	13	2018-03-14	2	\N
2021	10	5	13	2018-03-14	2	\N
2022	10	5	11	2018-03-14	4	\N
2023	10	5	13	2018-03-14	3	\N
2024	10	5	13	2018-03-14	3	\N
2025	10	5	13	2018-03-14	3	\N
2026	10	5	13	2018-03-14	3	\N
2027	10	5	13	2018-03-14	4	\N
2028	10	5	13	2018-03-14	4	\N
2029	10	5	13	2018-03-14	4	\N
2030	10	5	13	2018-03-14	4	\N
2031	10	5	13	2018-03-14	5	\N
2032	10	5	13	2018-03-14	5	\N
2033	10	5	13	2018-03-14	5	\N
2034	10	5	13	2018-03-14	5	\N
2035	10	5	13	2018-03-14	5	\N
2036	10	5	13	2018-03-14	6	\N
2037	10	5	13	2018-03-14	7	\N
2038	10	5	13	2018-03-14	7	\N
2039	10	5	13	2018-03-14	8	\N
2040	10	5	13	2018-03-14	8	\N
2041	10	5	13	2018-03-14	9	\N
2042	10	5	13	2018-03-14	9	\N
2043	9	4	10	2025-11-16	\N	\N
2044	9	4	11	2025-11-04	\N	\N
2045	10	5	11	2025-11-11	\N	\N
2046	12	5	12	2025-11-12	\N	\N
2047	10	5	12	2025-11-04	\N	\N
2048	11	5	11	2025-11-11	\N	\N
\.


--
-- Data for Name: Contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Contact" (id_contact, name, email, message, created_at, deleted_at, status, id_service) FROM stdin;
\.


--
-- Data for Name: Country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Country" (id_country, country_name, deleted_at) FROM stdin;
2	Argentina	\N
\.


--
-- Data for Name: Department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Department" (id_department, id_province, department_name, deleted_at) FROM stdin;
15	4	1° de Mayo	\N
16	5	Corrientes	\N
17	5	Concepción	\N
18	4	Sargento Cabral	\N
19	4	Plaza	\N
20	4	Basail	\N
21	4	Bermejo	\N
22	4	San Fernando	\N
23	6	Posadas	\N
24	5	San Miguel	\N
25	4	General San Martin	\N
26	6	Iguazú	\N
27	4	Capitan Solari	\N
28	4	Maipú	\N
\.


--
-- Data for Name: Environment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Environment" (id_environment, environment_name, deleted_at) FROM stdin;
18	Playa	\N
19	Selva riparia	\N
20	Pastizal	\N
21	-	\N
22	Selva	\N
23	Bosque 4	\N
24	Bosque 2	\N
25	Bosque 6	\N
26	Bosque 	\N
27	Bosque 6 	\N
28	Bosque 3	\N
29	Bosque 2 	\N
30	Bosque 1	\N
31	Pastizal quemado 3	\N
32	Pastizal quemado 4	\N
33	Pastizal control	\N
34	Pastizal quemado 2	\N
\.


--
-- Data for Name: Geolocation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Geolocation" (id_geolocation, latitude, longitude, altitude, source_type, tag, ihh, distance_to_river, id_locality, deleted_at) FROM stdin;
1022	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1023	-27.44875	-58.8715277777778	54	Google Earth	\N	\N	\N	22	\N
1024	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1025	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1026	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1027	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1028	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1029	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1030	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1031	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1032	-27.4488333333333	-58.8575555555556	55	Google Earth	\N	\N	\N	22	\N
1033	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1034	-27.44875	-58.8715277777778	55	Google Earth	\N	\N	\N	22	\N
1035	-27.4677777777778	-58.7816111111111	63	Google Earth	\N	\N	\N	23	\N
1036	-28.3931311111111	-57.889685	56	Google Earth	\N	\N	\N	24	\N
1037	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1038	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1039	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1040	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1041	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1042	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1043	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1044	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1045	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1046	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1047	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1048	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1049	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1050	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1051	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1052	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1053	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1054	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1055	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1056	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1057	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1058	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1059	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1060	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1061	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1062	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1063	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1064	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1065	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1066	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1067	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1068	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1069	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1070	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1071	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1072	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1073	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1074	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1075	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1076	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1077	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1078	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1079	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1080	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1081	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1082	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1083	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1084	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1085	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1086	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1087	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1088	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1089	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1090	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1091	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1092	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1093	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1094	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1095	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1096	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1097	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1098	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1099	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1100	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1101	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1102	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1103	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1104	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1105	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1106	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1107	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1108	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1109	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1110	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1111	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1112	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1113	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1114	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1115	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1116	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1117	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1118	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1119	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1120	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1121	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1122	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1123	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1124	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1125	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1126	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1127	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1128	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1129	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1130	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1131	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1132	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1133	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1134	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1135	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1136	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1137	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1138	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1139	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1140	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1141	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1142	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1143	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1144	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1145	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1146	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1147	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1148	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1149	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1150	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1151	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1152	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1153	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1154	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1155	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1156	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1157	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1158	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1159	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1160	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1161	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1162	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1163	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1164	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1165	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1166	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1167	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1168	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1169	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1170	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1171	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1172	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1173	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1174	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1175	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1176	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1177	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1178	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1179	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1180	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1181	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1182	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1183	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1184	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1185	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1186	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1187	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1188	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1189	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1190	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1191	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1192	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1193	-26.7926527777778	-58.7339333333333	65	Google Earth	\N	25	31.72	25	\N
1194	-27.7546944444444	-59.3986944444444	52	Google Earth	\N	\N	\N	27	\N
1195	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1196	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1197	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1198	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1199	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1200	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1201	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1202	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1203	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1204	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1205	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1206	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1207	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1208	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1209	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1210	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1211	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1212	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1213	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1214	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1215	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1216	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1217	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1218	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1219	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1220	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1221	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1222	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1223	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1224	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1225	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1226	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1227	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1228	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1229	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1230	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1231	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1232	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1233	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1234	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1235	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1236	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1237	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1238	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1239	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1240	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1241	-26.8004722222222	-58.6001111111111	79	Google Earth	\N	15	217.82	28	\N
1242	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1243	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1244	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1245	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1246	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1247	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1248	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1249	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1250	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1251	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1252	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1253	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1254	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1255	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1256	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1257	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1258	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1259	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1260	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1261	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1262	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1263	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1264	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1265	-26.9779444444444	-58.6508333333333	54	Google Earth	\N	35	146.54	29	\N
1266	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1267	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1268	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1269	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1270	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1271	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1272	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1273	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1274	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1275	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1276	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1277	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1278	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1279	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1280	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1281	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1282	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1283	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1284	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1285	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1286	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1287	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1288	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1289	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1290	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1291	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1292	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1293	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1294	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1295	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1296	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1297	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1298	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1299	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1300	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1301	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1302	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1303	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1304	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1305	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1306	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1307	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1308	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1309	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1310	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1311	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1312	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1313	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1314	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1315	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1316	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1317	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1318	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1319	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1320	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1321	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1322	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1323	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1324	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1325	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1326	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1327	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1328	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1329	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1330	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1331	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1332	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1333	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1334	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1335	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1336	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1337	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1338	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1339	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1340	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1341	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1342	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1343	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1344	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1345	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1346	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1347	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1348	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1349	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1350	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1351	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1352	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1353	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1354	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1355	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1356	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1357	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1358	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1359	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1360	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1361	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1362	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1363	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1364	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1365	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1366	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1367	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1368	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1369	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1370	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1371	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1372	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1373	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1374	-26.963	-58.6368055555556	54	Google Earth	\N	35	146.54	29	\N
1375	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1376	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1377	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1378	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1379	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1380	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1381	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1382	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1383	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1384	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1385	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1386	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1387	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1388	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1389	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1390	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1391	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1392	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1393	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1394	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1395	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1396	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1397	-27.5083888888889	-59.0814444444444	54	Google Earth	\N	\N	\N	30	\N
1398	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1399	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1400	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1401	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1402	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1403	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1404	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1405	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1406	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1407	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1408	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1409	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1410	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1411	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1412	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1413	-27.482	-55.8333888888889	114	Google Earth	\N	\N	\N	31	\N
1414	-27.6937777777778	-57.2193888888889	80	Google Earth	\N	\N	\N	32	\N
1415	-26.2757083333333	-59.9699027777778	95	Google Earth	\N	25	39.51	33	\N
1416	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1417	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1418	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1419	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1420	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1421	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1422	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1423	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1424	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1425	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1426	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1427	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1428	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1429	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1430	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1431	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1432	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1433	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1434	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1435	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1436	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1437	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1438	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1439	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1440	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1441	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1442	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1443	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1444	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1445	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1446	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1447	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1448	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1449	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1450	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1451	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1452	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1453	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1454	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1455	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1456	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1457	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1458	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1459	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1460	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1461	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1462	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1463	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1464	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1465	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1466	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1467	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1468	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1469	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1470	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1471	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1472	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1473	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1474	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1475	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1476	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1477	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1478	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1479	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1480	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1481	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1482	-26.2757083333333	-59.9699027777778	101	Google Earth	\N	25	39.51	33	\N
1483	-25.5180555555556	-54.1333333333333	198	Google Earth	\N	\N	\N	34	\N
1484	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1485	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1486	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1487	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1488	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1489	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1490	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1491	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1492	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1493	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1494	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1495	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1496	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1497	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1498	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1499	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1500	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1501	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1502	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1503	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1504	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1505	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1506	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1507	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1508	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1509	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1510	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1511	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1512	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1513	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1514	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1515	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1516	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1517	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1518	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1519	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1520	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1521	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1522	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1523	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1524	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1525	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1526	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1527	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1528	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1529	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1530	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1531	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1532	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1533	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1534	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1535	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1536	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1537	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1538	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1539	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1540	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1541	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1542	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1543	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1544	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1545	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1546	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1547	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1548	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1549	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1550	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1551	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1552	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1553	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1554	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1555	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1556	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1557	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1558	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1559	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1560	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1561	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1562	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1563	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1564	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1565	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1566	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1567	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1568	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1569	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1570	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1571	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1572	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1573	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1574	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1575	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1576	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1577	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1578	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1579	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1580	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1581	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1582	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1583	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1584	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1585	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1586	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1587	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1588	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1589	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1590	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1591	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1592	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1593	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1594	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1595	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1596	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1597	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1598	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1599	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1600	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1601	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1602	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1603	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1604	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1605	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1606	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1607	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1608	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1609	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1610	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1611	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1612	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1613	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1614	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1615	-26.804075	-59.6079305555556	82	Google Earth	\N	15	14.33	35	\N
1616	-26.7838055555556	-59.6051111111111	82	Google Earth	\N	15	25.38	36	\N
1617	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1618	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1619	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1620	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1621	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1622	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1623	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1624	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1625	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1626	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1627	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1628	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1629	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1630	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1631	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1632	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1633	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1634	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1635	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1636	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1637	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1638	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1639	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1640	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1641	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1642	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1643	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1644	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1645	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1646	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1647	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1648	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1649	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1650	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1651	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1652	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1653	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1654	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1655	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1656	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1657	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1658	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1659	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1660	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1661	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1662	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1663	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1664	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1665	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1666	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1667	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1668	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1669	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1670	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1671	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1672	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1673	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1674	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1675	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1676	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1677	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1678	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1679	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1680	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1681	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1682	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1683	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1684	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1685	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1686	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1687	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1688	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1689	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1690	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1691	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1692	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1693	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1694	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1695	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1696	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1697	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1698	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1699	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1700	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1701	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1702	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1703	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1704	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1705	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1706	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1707	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1708	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1709	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1710	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1711	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1712	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1713	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1714	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1715	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1716	-26.7837972222222	-59.6051027777778	85	Google Earth	\N	15	25.38	36	\N
1717	-27.4279166666667	-58.8669722222222	52	Google Earth	\N	50	204.37	37	\N
1718	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1719	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1720	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1721	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1722	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1723	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1724	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1725	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1726	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1727	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1728	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1729	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1730	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1731	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1732	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1733	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1734	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1735	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1736	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1737	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1738	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1739	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1740	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1741	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1742	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1743	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1744	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1745	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1746	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1747	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1748	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1749	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1750	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1751	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1752	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1753	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1754	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1755	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1756	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1757	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1758	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1759	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1760	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1761	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1762	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1763	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1764	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1765	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1766	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1767	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1768	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1769	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1770	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1771	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1772	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1773	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1774	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1775	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1776	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1777	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1778	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1779	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1780	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1781	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1782	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1783	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1784	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1785	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1786	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1787	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1788	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1789	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1790	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1791	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1792	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1793	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1794	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1795	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1796	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1797	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1798	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1799	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1800	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1801	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1802	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1803	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1804	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1805	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1806	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1807	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1808	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1809	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1810	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1811	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1812	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1813	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1814	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1815	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1816	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1817	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1818	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1819	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1820	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1821	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1822	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1823	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1824	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1825	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1826	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1827	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1828	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1829	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1830	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1831	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1832	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1833	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1834	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1835	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1836	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1837	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1838	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1839	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1840	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1841	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1842	-27.4288055555556	-58.8662777777778	52	Google Earth	\N	50	204.37	37	\N
1843	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1844	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1845	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1846	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1847	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1848	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1849	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1850	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1851	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1852	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1853	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1854	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1855	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1856	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1857	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1858	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1859	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1860	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1861	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1862	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1863	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1864	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1865	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1866	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1867	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1868	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1869	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1870	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1871	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1872	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1873	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1874	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1875	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1876	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1877	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1878	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1879	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1880	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1881	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1882	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1883	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1884	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1885	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1886	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1887	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1888	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1889	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1890	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1891	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1892	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1893	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1894	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1895	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1896	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1897	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1898	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1899	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1900	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1901	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1902	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1903	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1904	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1905	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1906	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1907	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1908	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1909	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1910	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1911	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1912	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1913	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1914	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1915	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1916	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1917	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1918	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1919	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1920	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1921	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1922	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1923	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1924	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1925	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1926	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1927	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1928	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1929	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1930	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1931	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1932	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1933	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1934	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1935	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1936	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1937	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1938	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1939	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1940	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1941	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1942	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1943	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1944	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1945	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1946	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1947	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1948	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1949	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1950	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1951	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1952	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1953	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1954	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1955	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1956	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1957	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1958	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1959	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1960	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1961	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1962	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1963	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1964	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1965	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1966	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1967	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1968	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1969	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1970	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1971	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1972	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1973	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1974	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1975	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1976	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1977	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1978	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1979	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1980	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1981	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1982	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1983	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1984	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1985	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1986	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1987	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1988	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1989	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1990	-27.3333055555556	-58.9660555555556	52	Google Earth	\N	35	92.95	38	\N
1991	-27.3973611111111	-59.02075	56	Google Earth	\N	\N	\N	39	\N
1992	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
1993	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
1994	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
1995	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
1996	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
1997	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
1998	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
1999	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2000	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2001	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2002	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2003	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2004	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2005	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2006	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2007	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2008	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2009	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2010	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2011	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2012	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2013	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2014	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2015	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2016	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2017	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2018	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2019	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2020	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2021	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2022	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2023	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2024	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2025	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2026	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2027	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2028	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2029	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2030	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2031	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2032	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2033	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2034	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2035	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2036	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2037	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2038	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2039	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2040	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2041	-26.9341111111111	-58.6473611111111	54	Google Earth	\N	50	128.14	42	\N
2042	-26.9341111111111	-58.6473611111111	54	Google Earth	zona 1	50	128.14	42	\N
\.


--
-- Data for Name: Locality; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Locality" (id_locality, id_department, locality_name, deleted_at) FROM stdin;
22	15	Barrio Pescadores	\N
23	16	Campus UNNE	\N
24	17	Concepción	\N
25	18	Estancia El Bagual	\N
26	19	Estancia los Alisos	\N
27	20	Estancia Maria Zaira	\N
28	21	Estancia Quintana	\N
29	21	Estancia San Carlos	\N
30	22	Estancia San Francisco	\N
31	23	Garupa	\N
32	24	Iberá - San Juan Poriahu	\N
33	25	Pampa del Indio	\N
34	26	Parque Iguazú	\N
35	27	Parque Nacional Chaco I	\N
36	27	Parque Nacional Chaco II	\N
37	15	Puerto Antequera	\N
38	15	Reserva los Chaguares	\N
39	22	Ruta 16. Km 19	\N
40	24	San Nicolas	\N
41	28	Tres Isletas	\N
42	21	Vedia	\N
\.


--
-- Data for Name: Observation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Observation" (id_observation, id_taxon, id_collection, id_geolocation, id_environment, id_caste, id_climate_data, abundance, deleted_at, id_identifier, identification_date, biology_notes, general_observations, conservation_status, confirmation_date, id_confirmer) FROM stdin;
1023	262	1024	1022	19	17	\N	1	\N	10	2014-03-12	\N	\N	\N	2015-09-28	11
1024	263	1025	1023	19	17	\N	1	\N	10	2014-03-12	\N	\N	\N	2015-09-29	11
1025	265	1026	1024	19	17	\N	1	\N	10	2014-03-12	\N	\N	\N	2015-09-30	11
1026	267	1027	1025	19	17	\N	1	\N	10	2014-04-10	\N	\N	\N	2015-09-30	11
1027	268	1028	1026	19	17	\N	1	\N	10	2014-03-12	\N	\N	\N	2015-09-30	11
1028	268	1029	1027	19	17	\N	1	\N	10	2014-03-12	\N	\N	\N	2015-09-30	11
1029	270	1030	1028	19	17	\N	1	\N	10	2014-03-12	\N	\N	\N	2015-09-30	11
1030	272	1031	1029	19	17	\N	1	\N	10	2014-03-12	\N	\N	\N	2015-10-02	11
1031	275	1032	1030	19	17	\N	1	\N	10	2014-03-12	\N	\N	\N	2015-09-28	11
1032	276	1033	1031	19	17	\N	1	\N	10	2014-03-12	\N	\N	\N	2015-09-28	11
1033	280	1034	1032	19	17	\N	1	\N	10	2014-07-07	\N	\N	\N	2015-10-01	11
1034	281	1035	1033	19	17	\N	1	\N	10	2015-10-01	\N	\N	\N	2015-10-01	11
1035	282	1036	1034	19	17	\N	1	\N	10	2015-10-01	\N	\N	\N	2015-10-01	11
1036	284	1037	1035	20	17	\N	1	\N	10	2014-04-09	\N	\N	\N	2015-09-28	11
1037	282	1038	1036	19	17	\N	1	\N	10	2015-10-01	\N	\N	\N	2015-10-01	11
1038	288	1039	1037	19	17	20	11	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1039	290	1040	1038	19	19	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1040	292	1041	1039	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1041	295	1042	1040	19	17	20	77	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1042	298	1043	1041	19	19	20	21	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1043	300	1044	1042	19	17	20	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1044	288	1045	1043	19	19	20	29	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1045	302	1046	1044	19	17	20	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1046	300	1047	1045	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1047	295	1048	1046	19	17	20	15	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1048	303	1049	1047	19	17	20	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1049	303	1050	1048	19	17	20	9	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1050	305	1051	1049	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1051	307	1052	1050	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1052	290	1053	1051	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1053	295	1054	1052	19	17	20	9	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1054	298	1055	1053	19	19	20	11	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1055	302	1056	1054	19	18	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1056	295	1057	1055	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1057	300	1058	1056	19	17	20	11	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1058	295	1059	1057	19	17	20	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1059	288	1060	1058	19	19	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1060	308	1061	1059	19	19	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1061	290	1062	1060	19	17	20	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1062	300	1063	1061	19	17	20	11	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1063	305	1064	1062	19	17	20	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1064	303	1065	1063	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1065	298	1066	1064	19	17	20	37	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1066	295	1067	1065	19	17	20	11	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1067	288	1068	1066	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1068	310	1069	1067	19	17	20	84	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1069	300	1070	1068	19	17	20	12	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1070	295	1071	1069	19	17	20	13	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1071	298	1072	1070	19	17	20	13	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1072	311	1073	1071	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1073	313	1074	1072	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1074	290	1075	1073	19	17	20	37	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1075	314	1076	1074	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1076	300	1077	1075	19	17	20	29	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1077	295	1078	1076	19	17	20	55	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1078	305	1079	1077	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1079	292	1080	1078	19	17	20	8	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1080	298	1081	1079	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1081	290	1082	1080	19	17	20	8	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1082	298	1083	1081	19	17	20	32	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1083	295	1084	1082	19	17	20	13	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1084	300	1085	1083	19	17	20	24	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1085	288	1086	1084	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1086	272	1087	1085	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1087	290	1088	1086	19	17	20	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1088	307	1089	1087	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1089	305	1090	1088	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1090	300	1091	1089	19	17	20	7	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1091	288	1092	1090	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1092	316	1093	1091	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1093	298	1094	1092	19	17	20	24	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1094	310	1095	1093	19	17	20	20	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1095	292	1096	1094	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1096	295	1097	1095	19	17	20	51	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1097	318	1098	1096	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1098	314	1099	1097	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1099	305	1100	1098	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1100	302	1101	1099	19	18	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1101	288	1102	1100	19	18	20	13	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1102	290	1103	1101	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1103	300	1104	1102	19	17	20	13	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1104	295	1105	1103	19	17	20	65	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1105	298	1106	1104	19	17	20	36	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1106	310	1107	1105	19	17	20	39	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1107	319	1108	1106	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1108	300	1109	1107	19	17	20	15	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1109	320	1110	1108	19	17	20	9	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1110	298	1111	1109	19	17	20	10	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1111	290	1112	1110	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1112	318	1113	1111	19	17	20	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1113	300	1114	1112	19	17	20	26	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1114	295	1115	1113	19	17	20	16	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1115	320	1116	1114	19	17	20	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1116	316	1117	1115	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1117	298	1118	1116	19	17	20	7	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1118	314	1119	1117	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1119	288	1120	1118	19	17	20	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1120	290	1121	1119	19	17	20	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1121	300	1122	1120	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1122	305	1123	1121	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1123	298	1124	1122	19	17	20	7	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1124	295	1125	1123	19	17	20	127	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1125	302	1126	1124	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1126	300	1127	1125	19	17	20	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1127	318	1128	1126	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1128	290	1129	1127	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1129	295	1130	1128	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1130	310	1131	1129	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1131	307	1132	1130	19	18	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1132	324	1133	1131	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1133	320	1134	1132	19	17	20	10	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1134	298	1135	1133	19	18	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1135	327	1136	1134	19	17	20	7	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1136	329	1137	1135	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1137	330	1138	1136	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1138	334	1139	1137	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1139	335	1140	1138	19	17	20	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1140	329	1141	1139	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1141	339	1142	1140	19	17	20	20	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1142	320	1143	1141	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1143	329	1144	1142	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1144	339	1145	1143	19	17	20	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1145	340	1146	1144	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1146	335	1147	1145	19	17	20	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1147	300	1148	1146	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1148	329	1149	1147	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1149	335	1150	1148	19	17	20	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1150	329	1151	1149	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1151	327	1152	1150	19	17	20	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1152	341	1153	1151	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1153	342	1154	1152	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1154	327	1155	1153	19	17	20	12	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1155	335	1156	1154	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1156	329	1157	1155	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1157	327	1158	1156	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1158	341	1159	1157	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1159	335	1160	1158	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1160	329	1161	1159	19	17	20	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1161	342	1162	1160	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1162	335	1163	1161	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1163	295	1164	1162	19	17	20	7	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1164	320	1165	1163	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1165	330	1166	1164	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1166	329	1167	1165	19	17	20	9	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1167	340	1168	1166	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1168	327	1169	1167	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1169	330	1170	1168	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1170	342	1171	1169	19	17	20	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1171	335	1172	1170	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1172	329	1173	1171	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1173	263	1174	1172	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1174	335	1175	1173	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1175	344	1176	1174	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1176	330	1177	1175	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1177	329	1178	1176	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1178	335	1179	1177	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1179	298	1180	1178	19	17	20	10	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1180	327	1181	1179	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1181	330	1182	1180	19	17	20	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1182	340	1183	1181	19	18	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1183	298	1184	1182	19	17	20	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1184	335	1185	1183	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1185	327	1186	1184	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1186	330	1187	1185	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1187	327	1188	1186	19	17	20	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1188	335	1189	1187	19	17	20	8	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1189	330	1190	1188	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1190	342	1191	1189	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1191	329	1192	1190	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1192	327	1193	1191	19	17	20	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1193	341	1194	1192	19	17	20	14	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1194	345	1195	1193	19	17	20	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1195	346	1196	1194	19	17	\N	1	\N	10	2014-04-14	\N	\N	\N	2015-10-02	11
1196	288	1197	1195	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1197	307	1198	1196	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1198	327	1199	1197	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1199	300	1200	1198	19	17	21	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1200	298	1201	1199	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1201	335	1202	1200	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1202	310	1203	1201	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1203	347	1204	1202	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1204	348	1205	1203	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1205	349	1206	1204	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1206	335	1207	1205	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1207	327	1208	1206	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1208	329	1209	1207	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1209	349	1210	1208	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1210	295	1211	1209	19	17	21	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1211	330	1212	1210	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1212	330	1213	1211	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1213	329	1214	1212	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1214	327	1215	1213	19	19	21	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1215	350	1216	1214	19	19	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1216	330	1217	1215	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1217	348	1218	1216	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1218	349	1219	1217	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1219	327	1220	1218	19	19	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1220	335	1221	1219	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1221	310	1222	1220	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1222	335	1223	1221	19	17	21	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1223	330	1224	1222	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1224	349	1225	1223	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1225	295	1226	1224	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1226	330	1227	1225	19	17	21	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1227	351	1228	1226	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1228	330	1229	1227	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1229	310	1230	1228	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1230	349	1231	1229	19	17	21	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1231	330	1232	1230	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1232	329	1233	1231	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1233	295	1234	1232	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1234	352	1235	1233	19	17	21	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1235	353	1236	1234	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1236	330	1237	1235	19	17	21	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1237	327	1238	1236	19	19	21	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1238	349	1239	1237	19	17	21	8	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1239	341	1240	1238	19	17	21	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1240	295	1241	1239	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1241	353	1242	1240	19	17	21	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1242	349	1243	1241	19	17	21	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1243	355	1244	1242	19	17	22	11	\N	10	2014-04-09	\N	\N	ECB	2015-09-28	11
1244	356	1245	1243	19	17	23	1	\N	10	2014-04-09	\N	\N	ECB	2015-09-28	11
1245	284	1246	1244	20	17	23	1	\N	10	2014-04-09	\N	\N	ECB	2015-09-28	11
1246	318	1247	1245	20	17	23	1	\N	10	2014-03-12	\N	\N	ECB	2015-09-28	11
1247	263	1248	1246	19	17	22	1	\N	10	2014-03-12	\N	\N	ECB	2015-09-29	11
1248	357	1249	1247	19	17	23	1	\N	10	2014-03-12	\N	\N	ECB	2015-09-29	11
1249	358	1250	1248	20	20	22	1	\N	10	2014-04-09	\N	\N	ECB	2015-09-30	11
1250	359	1251	1249	19	21	23	1	\N	10	2014-04-10	\N	\N	ECB	2015-09-30	11
1251	360	1252	1250	19	20	23	1	\N	10	2014-04-10	\N	\N	ECB	2015-09-30	11
1252	319	1253	1251	20	17	22	1	\N	10	2014-04-09	\N	\N	ECB	2015-10-01	11
1253	300	1254	1252	20	17	22	1	\N	10	2014-04-09	\N	\N	ECB	2015-09-30	11
1254	346	1255	1253	19	17	23	1	\N	10	2014-04-10	\N	\N	ECB	2015-10-02	11
1255	361	1256	1254	20	17	22	1	\N	11	2015-10-03	\N	\N	ECB	2015-10-03	11
1256	362	1257	1255	19	17	23	1	\N	11	2015-10-03	\N	\N	ECB	2015-10-03	11
1257	363	1258	1256	19	17	23	1	\N	11	2015-10-03	\N	\N	ECB	2015-10-03	11
1258	364	1259	1257	20	17	22	1	\N	10	2014-04-09	\N	\N	ECB	2015-09-30	11
1259	364	1260	1258	19	17	23	1	\N	10	2014-04-10	\N	\N	ECB	2015-09-30	11
1260	365	1261	1259	20	17	22	1	\N	10	2014-04-09	\N	\N	ECB	2015-09-30	11
1261	366	1262	1260	20	17	22	1	\N	10	2014-04-09	\N	\N	ECB	2015-09-30	11
1262	254	1263	1261	20	17	22	1	\N	10	2014-04-09	\N	\N	ECB	2015-09-30	11
1263	367	1264	1262	19	17	23	1	\N	11	2015-10-03	\N	\N	ECB	2015-09-30	11
1264	275	1265	1263	19	17	23	1	\N	10	2014-04-10	\N	\N	ECB	2015-09-30	11
1265	276	1266	1264	20	17	22	1	\N	10	2014-04-09	\N	\N	ECB	2015-09-30	11
1266	369	1267	1265	20	17	22	1	\N	10	2014-04-09	\N	\N	ECB	2015-09-30	11
1267	302	1268	1266	19	17	24	18	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1268	290	1269	1267	19	17	24	15	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1269	300	1270	1268	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1270	295	1271	1269	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1271	298	1272	1270	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1272	290	1273	1271	19	17	24	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1273	302	1274	1272	19	17	24	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1274	298	1275	1273	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1275	302	1276	1274	19	17	24	9	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1276	370	1277	1275	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1277	290	1278	1276	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1278	300	1279	1277	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1279	371	1280	1278	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1280	302	1281	1279	19	17	24	13	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1281	372	1282	1280	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1282	290	1283	1281	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1283	290	1284	1282	19	17	24	7	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1284	302	1285	1283	19	17	24	8	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1285	373	1286	1284	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1286	370	1287	1285	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1287	290	1288	1286	19	17	24	7	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1288	302	1289	1287	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1289	275	1290	1288	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1290	302	1291	1289	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1291	290	1292	1290	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1292	370	1293	1291	19	17	24	7	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1293	329	1294	1292	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1294	290	1295	1293	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1295	302	1296	1294	19	17	24	17	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1296	329	1297	1295	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1297	310	1298	1296	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1298	302	1299	1297	19	17	24	12	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1299	290	1300	1298	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1300	290	1301	1299	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1301	302	1302	1300	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1302	302	1303	1301	19	17	24	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1303	290	1304	1302	19	17	24	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1304	372	1305	1303	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1305	292	1306	1304	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1306	292	1307	1305	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1307	370	1308	1306	19	17	24	8	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1308	302	1309	1307	19	17	24	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1309	290	1310	1308	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1310	298	1311	1309	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1311	302	1312	1310	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1312	329	1313	1311	19	17	24	8	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1313	330	1314	1312	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1314	329	1315	1313	19	17	24	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1315	334	1316	1314	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1316	374	1317	1315	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1317	330	1318	1316	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1318	348	1319	1317	19	17	24	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1319	329	1320	1318	19	17	24	9	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1320	298	1321	1319	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1321	330	1322	1320	19	17	24	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1322	330	1323	1321	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1323	375	1324	1322	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1324	355	1325	1323	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1325	327	1326	1324	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1326	295	1327	1325	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1327	300	1328	1326	19	17	24	17	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1328	330	1329	1327	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1329	349	1330	1328	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1330	329	1331	1329	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1331	376	1332	1330	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1332	290	1333	1331	19	17	24	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1333	300	1334	1332	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1334	330	1335	1333	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1335	295	1336	1334	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1336	327	1337	1335	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1337	367	1338	1336	19	17	24	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1338	349	1339	1337	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1339	268	1340	1338	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1340	340	1341	1339	19	18	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1341	300	1342	1340	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1342	329	1343	1341	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1343	351	1344	1342	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1344	330	1345	1343	19	17	24	7	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1345	377	1346	1344	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1346	330	1347	1345	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1347	329	1348	1346	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1348	295	1349	1347	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1349	379	1350	1348	19	17	24	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1350	367	1351	1349	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1351	367	1352	1350	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1352	341	1353	1351	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1353	329	1354	1352	19	17	24	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1354	349	1355	1353	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1355	341	1356	1354	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1356	329	1357	1355	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1357	330	1358	1356	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1358	330	1359	1357	19	17	24	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1359	349	1360	1358	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1360	329	1361	1359	19	17	24	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1361	356	1362	1360	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1362	329	1363	1361	19	17	24	8	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1363	330	1364	1362	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1364	327	1365	1363	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1365	329	1366	1364	19	17	24	11	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1366	329	1367	1365	19	17	24	7	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1367	298	1368	1366	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1368	330	1369	1367	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1369	329	1370	1368	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1370	300	1371	1369	19	17	24	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1371	377	1372	1370	19	22	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1372	349	1373	1371	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1373	379	1374	1372	19	17	24	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1374	290	1375	1373	19	17	24	15	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1375	373	1376	1374	19	17	24	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1376	284	1377	1375	22	17	\N	1	\N	10	2014-04-09	\N	\N	\N	2015-09-28	11
1377	380	1378	1376	22	17	\N	1	\N	11	2015-10-01	\N	\N	\N	2015-10-01	11
1378	290	1379	1377	22	17	\N	1	\N	10	2014-04-09	\N	\N	\N	2015-10-01	11
1379	381	1380	1378	20	17	\N	1	\N	10	2014-03-03	\N	\N	\N	2015-09-28	11
1380	262	1381	1379	22	17	\N	1	\N	10	2014-03-12	\N	\N	\N	2015-09-28	11
1381	265	1382	1380	22	17	\N	1	\N	10	2014-04-09	\N	\N	\N	2015-09-30	11
1382	358	1383	1381	20	23	\N	1	\N	10	2014-04-10	\N	\N	\N	2015-09-30	11
1383	382	1384	1382	22	24	\N	1	\N	10	2014-04-09	\N	\N	\N	2015-09-30	11
1384	383	1385	1383	22	20	\N	1	\N	10	2014-04-09	\N	\N	\N	2015-09-30	11
1385	327	1386	1384	22	17	\N	1	\N	10	2014-04-09	\N	\N	\N	2015-10-01	11
1386	270	1387	1385	22	17	\N	1	\N	10	2014-04-09	\N	\N	\N	2015-10-01	11
1387	300	1388	1386	20	17	\N	1	\N	10	2014-04-10	\N	\N	\N	2015-09-30	11
1388	384	1389	1387	22	17	\N	1	\N	10	2014-04-09	\N	\N	\N	2015-10-02	11
1389	346	1390	1388	22	17	\N	1	\N	10	2014-04-09	\N	\N	\N	2015-10-02	11
1390	386	1391	1389	19	17	\N	1	\N	10	2014-04-07	\N	\N	\N	2015-10-02	11
1391	387	1392	1390	19	17	\N	1	\N	11	2015-10-03	\N	\N	\N	2015-10-03	11
1392	388	1393	1391	19	17	\N	1	\N	10	2014-04-07	\N	\N	\N	2015-09-30	11
1393	254	1394	1392	19	17	\N	1	\N	10	2014-04-07	\N	\N	\N	2015-09-30	11
1394	389	1395	1393	19	17	\N	1	\N	10	2014-04-07	\N	\N	\N	2015-09-30	11
1395	275	1396	1394	19	17	\N	1	\N	10	2014-04-07	\N	\N	\N	2015-09-30	11
1396	369	1397	1395	19	17	\N	1	\N	10	2014-04-07	\N	\N	\N	2015-10-01	11
1397	390	1398	1396	19	17	\N	1	\N	10	2014-04-07	\N	\N	\N	2015-10-01	11
1398	316	1399	1397	19	17	\N	1	\N	10	2014-04-07	\N	\N	\N	2015-10-01	11
1399	392	1400	1398	22	17	\N	2	\N	10	2015-09-29	\N	\N	\N	2015-09-29	11
1400	346	1401	1399	19	17	\N	11	\N	10	2014-04-10	\N	\N	\N	2015-10-02	11
1401	393	1402	1400	22	17	\N	6	\N	10	2015-09-29	\N	\N	\N	2015-09-29	11
1402	394	1403	1401	22	17	\N	161	\N	10	2018-09-15	\N	\N	\N	\N	\N
1403	395	1404	1402	22	17	\N	5	\N	10	2018-09-15	\N	\N	\N	\N	\N
1404	265	1405	1403	22	17	\N	197	\N	10	2018-09-15	\N	\N	\N	\N	\N
1405	367	1406	1404	22	17	\N	2	\N	10	2018-09-15	\N	\N	\N	\N	\N
1406	396	1407	1405	22	17	\N	25	\N	10	2018-09-15	\N	\N	\N	\N	\N
1407	307	1408	1406	22	17	\N	5	\N	10	2018-09-15	\N	\N	\N	\N	\N
1408	397	1409	1407	22	17	\N	99	\N	10	2018-09-15	\N	\N	\N	\N	\N
1409	398	1410	1408	22	17	\N	3	\N	10	2018-09-15	\N	\N	\N	\N	\N
1410	300	1411	1409	22	17	\N	204	\N	10	2018-09-15	\N	\N	\N	\N	\N
1411	399	1412	1410	22	17	\N	16	\N	10	2018-09-15	\N	\N	\N	\N	\N
1412	356	1413	1411	22	17	\N	56	\N	10	2018-09-15	\N	\N	\N	\N	\N
1413	400	1414	1412	22	17	\N	3	\N	10	2018-09-15	\N	\N	\N	\N	\N
1414	402	1415	1413	22	17	\N	220	\N	10	2018-09-15	\N	\N	\N	\N	\N
1415	405	1416	1414	20	17	\N	1	\N	10	2014-06-12	\N	\N	\N	2015-10-02	11
1416	290	1417	1416	19	17	25	5	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1417	275	1418	1417	19	17	25	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1418	290	1419	1418	19	17	25	8	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1419	397	1420	1419	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1420	310	1421	1420	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1421	330	1422	1421	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1422	305	1423	1422	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1423	290	1424	1423	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1424	316	1425	1424	19	17	25	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1425	275	1426	1425	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1426	290	1427	1426	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1427	290	1428	1427	19	17	25	10	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1428	373	1429	1428	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1429	290	1430	1429	19	17	25	6	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1430	373	1431	1430	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1431	335	1432	1431	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1432	406	1433	1432	19	17	25	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1433	310	1434	1433	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1434	320	1435	1434	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1435	275	1436	1435	19	17	25	13	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1436	290	1437	1436	19	17	25	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1437	397	1438	1437	19	17	25	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1438	310	1439	1438	19	17	25	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1439	290	1440	1439	19	17	25	13	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1440	298	1441	1440	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1441	275	1442	1441	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1442	300	1443	1442	19	17	25	4	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1443	290	1444	1443	19	17	25	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1444	275	1445	1444	19	17	25	6	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1445	298	1446	1445	19	17	25	5	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1446	290	1447	1446	19	17	25	8	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1447	275	1448	1447	19	17	25	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1448	406	1449	1448	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1449	329	1450	1449	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1450	290	1451	1450	19	17	25	5	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1451	329	1452	1451	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1452	320	1453	1452	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1453	298	1454	1453	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1454	316	1455	1454	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1455	290	1456	1455	19	17	25	4	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1456	329	1457	1456	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1457	406	1458	1457	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1458	319	1459	1458	19	17	25	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1459	329	1460	1459	19	17	25	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1460	389	1461	1460	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1461	310	1462	1461	19	17	25	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1462	406	1463	1462	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1463	300	1464	1463	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1464	275	1465	1464	19	17	25	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1465	310	1466	1465	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1466	290	1467	1466	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1467	275	1468	1467	19	17	25	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1468	407	1469	1468	19	17	25	4	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1469	290	1470	1469	19	17	25	4	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1470	275	1471	1470	19	17	25	5	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1471	310	1472	1471	19	17	25	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1472	329	1473	1472	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1473	319	1474	1473	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1474	300	1475	1474	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1475	263	1476	1475	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1476	298	1477	1476	19	17	25	5	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1477	310	1478	1477	19	17	25	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1478	290	1479	1478	19	17	25	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1479	298	1480	1479	19	17	25	12	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1480	310	1481	1480	19	17	25	6	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1481	330	1482	1481	19	17	25	4	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1482	329	1483	1482	19	17	25	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1483	400	1484	1483	22	17	\N	2	\N	10	2014-04-09	\N	\N	\N	2015-09-28	11
1484	329	1485	1484	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1485	329	1486	1485	19	17	26	9	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1486	300	1487	1486	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1487	376	1488	1487	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1488	376	1489	1488	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1489	329	1490	1489	19	17	26	8	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1490	298	1491	1490	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1491	335	1492	1491	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1492	310	1493	1492	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1493	349	1494	1493	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1494	329	1495	1494	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1495	376	1496	1495	19	17	26	7	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1496	329	1497	1496	19	17	26	16	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1497	410	1498	1497	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1498	329	1499	1498	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1499	330	1500	1499	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1500	411	1501	1500	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1501	349	1502	1501	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1502	349	1503	1502	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1503	397	1504	1503	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1504	349	1505	1504	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1505	329	1506	1505	19	17	26	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1506	298	1507	1506	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1507	329	1508	1507	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1508	334	1509	1508	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1509	329	1510	1509	19	17	26	7	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1510	349	1511	1510	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1511	300	1512	1511	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1512	298	1513	1512	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1513	310	1514	1513	19	17	26	8	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1514	329	1515	1514	19	19	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1515	298	1516	1515	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1516	330	1517	1516	19	17	26	9	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1517	329	1518	1517	19	19	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1518	341	1519	1518	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1519	346	1520	1519	19	17	26	7	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1520	335	1521	1520	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1521	349	1522	1521	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1522	397	1523	1522	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1523	376	1524	1523	19	17	26	57	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1524	413	1525	1524	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1525	310	1526	1525	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1526	275	1527	1526	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1527	300	1528	1527	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1528	376	1529	1528	19	17	26	44	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1529	298	1530	1529	19	17	26	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1530	397	1531	1530	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1531	376	1532	1531	19	17	26	22	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1532	372	1533	1532	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1533	275	1534	1533	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1534	298	1535	1534	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1535	292	1536	1535	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1536	307	1537	1536	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1537	292	1538	1537	19	18	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1538	376	1539	1538	19	17	26	49	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1539	298	1540	1539	19	17	26	23	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1540	397	1541	1540	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1541	397	1542	1541	19	17	26	10	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1542	292	1543	1542	19	18	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1543	302	1544	1543	19	18	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1544	290	1545	1544	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1545	376	1546	1545	19	17	26	18	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1546	298	1547	1546	19	17	26	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1547	298	1548	1547	19	17	26	23	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1548	300	1549	1548	19	17	26	9	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1549	292	1550	1549	19	18	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1550	302	1551	1550	19	18	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1551	397	1552	1551	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1552	295	1553	1552	19	17	26	51	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1553	298	1554	1553	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1554	300	1555	1554	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1555	372	1556	1555	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1556	373	1557	1556	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1557	272	1558	1557	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1558	295	1559	1558	19	17	26	9	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1559	300	1560	1559	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1560	298	1561	1560	19	17	26	18	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1561	372	1562	1561	19	17	26	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1562	275	1563	1562	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1563	414	1564	1563	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1564	295	1565	1564	19	17	26	26	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1565	300	1566	1565	19	17	26	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1566	298	1567	1566	19	17	26	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1567	320	1568	1567	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1568	288	1569	1568	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1569	415	1570	1569	19	17	26	9	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1570	300	1571	1570	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1571	295	1572	1571	19	17	26	15	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1572	290	1573	1572	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1573	376	1574	1573	19	17	26	9	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1574	397	1575	1574	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1575	300	1576	1575	19	17	26	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1576	372	1577	1576	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1577	376	1578	1577	19	17	26	76	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1578	372	1579	1578	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1579	300	1580	1579	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1580	298	1581	1580	19	17	26	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1581	292	1582	1581	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1582	288	1583	1582	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1583	300	1584	1583	19	17	26	13	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1584	416	1585	1584	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1585	298	1586	1585	19	17	26	7	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1586	372	1587	1586	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1587	295	1588	1587	19	17	26	14	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1588	372	1589	1588	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1589	292	1590	1589	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1590	295	1591	1590	19	17	26	30	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1591	417	1592	1591	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1592	298	1593	1592	19	17	26	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1593	298	1594	1593	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1594	295	1595	1594	19	17	26	5	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1595	300	1596	1595	19	17	26	8	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1596	275	1597	1596	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1597	347	1598	1597	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1598	373	1599	1598	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1599	372	1600	1599	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1600	399	1601	1600	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1601	397	1602	1601	19	17	26	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1602	418	1603	1602	19	17	26	4	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1603	275	1604	1603	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1604	419	1605	1604	19	17	26	6	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1605	420	1606	1605	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1606	420	1607	1606	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1607	347	1608	1607	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1608	347	1609	1608	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1609	397	1610	1609	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1610	347	1611	1610	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1611	347	1612	1611	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1612	373	1613	1612	19	17	26	2	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1613	272	1614	1613	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1614	298	1615	1614	19	17	26	3	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1615	397	1616	1615	19	17	26	1	\N	10	2019-10-18	\N	\N	ECI	\N	\N
1616	339	1617	1616	19	17	27	3	\N	10	2019-03-11	\N	\N	ECB	\N	\N
1617	351	1618	1617	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1618	348	1619	1618	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1619	374	1620	1619	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1620	330	1621	1620	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1621	329	1622	1621	19	17	28	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1622	330	1623	1622	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1623	374	1624	1623	19	17	28	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1624	330	1625	1624	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1625	329	1626	1625	19	17	28	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1626	348	1627	1626	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1627	329	1628	1627	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1628	334	1629	1628	19	17	28	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1629	254	1630	1629	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1630	374	1631	1630	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1631	374	1632	1631	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1632	330	1633	1632	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1633	421	1634	1633	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1634	290	1635	1634	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1635	330	1636	1635	19	17	28	64	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1636	330	1637	1636	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1637	349	1638	1637	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1638	374	1639	1638	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1639	329	1640	1639	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1640	376	1641	1640	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1641	329	1642	1641	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1642	330	1643	1642	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1643	329	1644	1643	19	19	28	6	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1644	348	1645	1644	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1645	374	1646	1645	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1646	397	1647	1646	19	17	28	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1647	254	1648	1647	19	19	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1648	348	1649	1648	19	19	28	7	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1649	330	1650	1649	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1650	329	1651	1650	19	19	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1651	422	1652	1651	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1652	329	1653	1652	19	19	28	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1653	329	1654	1653	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1654	330	1655	1654	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1655	330	1656	1655	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1656	329	1657	1656	19	19	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1657	329	1658	1657	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1658	374	1659	1658	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1659	349	1660	1659	19	17	28	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1660	374	1661	1660	19	17	28	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1661	423	1662	1661	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1662	254	1663	1662	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1663	329	1664	1663	19	17	28	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1664	254	1665	1664	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1665	424	1666	1665	19	17	28	6	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1666	300	1667	1666	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1667	295	1668	1667	19	17	28	41	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1668	275	1669	1668	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1669	288	1670	1669	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1670	423	1671	1670	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1671	295	1672	1671	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1672	298	1673	1672	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1673	298	1674	1673	19	17	28	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1674	290	1675	1674	19	17	28	10	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1675	425	1676	1675	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1676	292	1677	1676	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1677	295	1678	1677	19	17	28	47	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1678	275	1679	1678	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1679	290	1680	1679	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1680	292	1681	1680	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1681	295	1682	1681	19	17	28	25	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1682	397	1683	1682	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1683	310	1684	1683	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1684	320	1685	1684	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1685	290	1686	1685	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1686	295	1687	1686	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1687	417	1688	1687	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1688	397	1689	1688	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1689	295	1690	1689	19	17	28	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1690	300	1691	1690	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1691	295	1692	1691	19	17	28	12	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1692	295	1693	1692	19	17	28	6	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1693	397	1694	1693	19	17	28	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1694	295	1695	1694	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1695	290	1696	1695	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1696	290	1697	1696	19	17	28	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1697	295	1698	1697	19	17	28	47	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1698	417	1699	1698	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1699	300	1700	1699	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1700	426	1701	1700	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1701	427	1702	1701	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1702	295	1703	1702	19	17	28	19	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1703	295	1704	1703	19	17	28	14	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1704	428	1705	1704	19	17	28	6	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1705	295	1706	1705	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1706	310	1707	1706	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1707	307	1708	1707	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1708	428	1709	1708	19	17	28	20	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1709	272	1710	1709	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1710	428	1711	1710	19	17	28	6	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1711	310	1712	1711	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1712	428	1713	1712	19	17	28	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1713	427	1714	1713	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1714	428	1715	1714	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1715	425	1716	1715	19	17	28	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1716	295	1717	1716	19	17	28	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1717	465	1718	1717	19	17	29	1	\N	11	2015-10-01	\N	\N	ECD	2015-10-01	11
1718	466	1719	1718	19	18	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1719	467	1720	1719	19	18	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1720	467	1721	1720	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1721	377	1722	1721	19	17	30	2	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1722	377	1723	1722	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1723	350	1724	1723	19	17	30	5	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1724	310	1725	1724	19	17	30	4	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1725	298	1726	1725	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1726	334	1727	1726	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1727	468	1728	1727	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1728	377	1729	1728	19	17	30	6	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1729	469	1730	1729	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1730	327	1731	1730	19	17	30	9	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1731	329	1732	1731	19	17	30	7	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1732	330	1733	1732	19	17	30	3	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1733	468	1734	1733	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1734	470	1735	1734	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1735	377	1736	1735	19	17	30	6	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1736	327	1737	1736	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1737	334	1738	1737	19	17	30	3	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1738	330	1739	1738	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1739	468	1740	1739	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1740	327	1741	1740	19	17	30	5	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1741	329	1742	1741	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1742	295	1743	1742	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1743	280	1744	1743	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1744	310	1745	1744	19	25	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1745	280	1746	1745	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1746	411	1747	1746	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1747	330	1748	1747	19	17	30	7	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1748	329	1749	1748	19	17	30	4	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1749	327	1750	1749	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1750	329	1751	1750	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1751	329	1752	1751	19	17	30	2	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1752	330	1753	1752	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1753	334	1754	1753	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1754	330	1755	1754	19	17	30	4	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1755	329	1756	1755	19	17	30	2	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1756	350	1757	1756	19	17	30	5	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1757	329	1758	1757	19	17	30	6	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1758	411	1759	1758	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1759	330	1760	1759	19	17	30	4	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1760	350	1761	1760	19	17	30	6	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1761	471	1762	1761	19	17	30	2	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1762	330	1763	1762	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1763	330	1764	1763	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1764	329	1765	1764	19	17	30	3	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1765	327	1766	1765	19	17	30	2	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1766	280	1767	1766	19	17	30	13	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1767	329	1768	1767	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1768	330	1769	1768	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1769	327	1770	1769	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1770	350	1771	1770	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1771	455	1772	1771	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1772	330	1773	1772	19	17	30	4	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1773	329	1774	1773	19	17	30	5	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1774	327	1775	1774	19	26	30	3	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1775	468	1776	1775	19	17	30	2	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1776	329	1777	1776	19	17	30	6	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1777	330	1778	1777	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1778	329	1779	1778	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1779	330	1780	1779	19	17	30	2	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1780	411	1781	1780	19	17	30	4	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1781	334	1782	1781	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1782	422	1783	1782	19	17	30	2	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1783	329	1784	1783	19	17	30	2	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1784	327	1785	1784	19	17	30	1	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1785	397	1786	1785	19	17	31	13	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1786	468	1787	1786	19	17	32	12	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1787	327	1788	1787	19	17	30	2	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1788	330	1789	1788	19	17	30	29	\N	15	2019-03-11	\N	\N	ECD	\N	\N
1789	290	1790	1789	19	17	30	26	\N	10	2019-10-11	\N	\N	ECD	\N	\N
1790	300	1791	1790	19	17	30	1	\N	10	2019-10-12	\N	\N	ECD	\N	\N
1791	310	1792	1791	19	17	30	1	\N	10	2019-10-13	\N	\N	ECD	\N	\N
1792	290	1793	1792	19	17	30	28	\N	10	2019-10-11	\N	\N	ECD	\N	\N
1793	300	1794	1793	19	17	30	1	\N	10	2019-10-12	\N	\N	ECD	\N	\N
1794	290	1795	1794	19	17	30	17	\N	10	2019-10-11	\N	\N	ECD	\N	\N
1795	300	1796	1795	19	17	30	2	\N	10	2019-10-17	\N	\N	ECD	\N	\N
1796	310	1797	1796	19	17	30	4	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1797	300	1798	1797	19	19	30	82	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1798	290	1799	1798	19	17	30	17	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1799	350	1800	1799	19	17	30	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1800	290	1801	1800	19	17	30	10	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1801	300	1802	1801	19	17	30	14	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1802	290	1803	1802	19	17	30	16	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1803	300	1804	1803	19	17	30	7	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1804	290	1805	1804	19	17	30	4	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1805	372	1806	1805	19	17	30	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1806	300	1807	1806	19	17	30	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1807	300	1808	1807	19	17	30	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1808	290	1809	1808	19	17	30	27	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1809	290	1810	1809	19	17	30	28	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1810	310	1811	1810	19	17	30	40	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1811	417	1812	1811	19	17	30	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1812	300	1813	1812	19	17	30	12	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1813	290	1814	1813	19	17	30	17	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1814	290	1815	1814	19	17	30	31	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1815	300	1816	1815	19	17	30	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1816	310	1817	1816	19	17	30	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1817	275	1818	1817	19	17	30	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1818	290	1819	1818	19	17	30	19	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1819	290	1820	1819	19	17	30	15	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1820	300	1821	1820	19	17	30	7	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1821	300	1822	1821	19	17	30	24	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1822	310	1823	1822	19	17	30	10	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1823	310	1824	1823	19	17	30	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1824	472	1825	1824	19	17	30	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1825	290	1826	1825	19	17	30	4	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1826	300	1827	1826	19	17	30	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1827	290	1828	1827	19	17	30	10	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1828	310	1829	1828	19	17	30	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1829	290	1830	1829	19	17	30	7	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1830	300	1831	1830	19	17	30	5	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1831	290	1832	1831	19	17	30	5	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1832	300	1833	1832	19	17	30	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1833	475	1834	1833	19	17	30	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1834	290	1835	1834	19	17	30	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1835	275	1836	1835	19	17	30	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1836	290	1837	1836	19	17	30	7	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1837	300	1838	1837	19	17	30	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1838	275	1839	1838	19	17	30	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1839	290	1840	1839	19	17	30	11	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1840	300	1841	1840	19	17	30	6	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1841	290	1842	1841	19	17	30	25	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1842	300	1843	1842	19	17	30	31	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1843	292	1844	1843	19	17	33	2	\N	10	2015-11-20	\N	\N	ECB	2015-10-03	11
1844	476	1845	1844	19	17	33	1	\N	10	2015-11-20	\N	\N	ECB	2015-10-03	11
1845	350	1846	1845	19	17	34	25	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1846	330	1847	1846	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1847	329	1848	1847	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1848	329	1849	1848	19	27	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1849	335	1850	1849	19	28	34	13	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1850	330	1851	1850	19	17	34	7	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1851	334	1852	1851	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1852	327	1853	1852	19	29	34	10	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1853	300	1854	1853	19	17	34	1	\N	10	2018-05-11	\N	\N	ECB	\N	\N
1854	477	1855	1854	19	17	34	2	\N	10	2018-05-11	\N	\N	ECB	\N	\N
1855	329	1856	1855	19	17	34	5	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1856	350	1857	1856	19	17	34	2	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1857	353	1858	1857	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1858	330	1859	1858	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1859	329	1860	1859	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1860	353	1861	1860	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1861	456	1862	1861	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1862	329	1863	1862	19	17	34	2	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1863	330	1864	1863	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1864	334	1865	1864	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1865	329	1866	1865	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1866	330	1867	1866	19	17	34	4	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1867	335	1868	1867	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1868	329	1869	1868	19	17	34	4	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1869	327	1870	1869	19	17	34	2	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1870	329	1871	1870	19	17	34	9	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1871	330	1872	1871	19	17	34	11	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1872	334	1873	1872	19	17	34	2	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1873	329	1874	1873	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1874	350	1875	1874	19	17	34	9	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1875	350	1876	1875	19	17	34	14	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1876	330	1877	1876	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1877	353	1878	1877	19	17	34	4	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1878	329	1879	1878	19	17	34	7	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1879	353	1880	1879	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1880	375	1881	1880	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1881	334	1882	1881	19	17	34	13	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1882	329	1883	1882	19	30	34	51	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1883	330	1884	1883	19	17	34	25	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1884	353	1885	1884	19	28	34	2	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1885	456	1886	1885	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1886	472	1887	1886	19	27	34	12	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1887	350	1888	1887	19	17	34	32	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1888	472	1889	1888	19	18	34	7	\N	10	2018-05-11	\N	\N	ECB	\N	\N
1889	472	1890	1889	19	18	34	1	\N	10	2018-05-11	\N	\N	ECB	\N	\N
1890	334	1891	1890	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1891	329	1892	1891	19	19	34	9	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1892	353	1893	1892	19	17	34	5	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1893	330	1894	1893	19	17	34	4	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1894	350	1895	1894	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1895	330	1896	1895	19	17	34	3	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1896	327	1897	1896	19	17	34	3	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1897	329	1898	1897	19	17	34	1	\N	15	2018-05-11	\N	\N	ECB	\N	\N
1898	290	1899	1898	19	17	34	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1899	275	1900	1899	19	17	34	7	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1900	310	1901	1900	19	17	34	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1901	316	1902	1901	19	17	34	12	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1902	300	1903	1902	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1903	300	1904	1903	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1904	316	1905	1904	19	28	34	102	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1905	300	1906	1905	19	17	34	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1906	275	1907	1906	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1907	298	1908	1907	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1908	290	1909	1908	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1909	418	1910	1909	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1910	330	1911	1910	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1911	356	1912	1911	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1912	334	1913	1912	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1913	320	1914	1913	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1914	372	1915	1914	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1915	397	1916	1915	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1916	295	1917	1916	19	17	34	17	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1917	292	1918	1917	19	17	35	22	\N	10	2019-10-19	\N	\N	ECB	\N	\N
1918	302	1919	1918	19	17	35	13	\N	10	2019-10-19	\N	\N	ECB	\N	\N
1919	372	1920	1919	19	17	34	41	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1920	290	1921	1920	19	17	34	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1921	275	1922	1921	19	17	34	19	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1922	307	1923	1922	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1923	420	1924	1923	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1924	300	1925	1924	19	17	34	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1925	290	1926	1925	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1926	300	1927	1926	19	17	34	11	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1927	276	1928	1927	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1928	290	1929	1928	19	17	34	6	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1929	372	1930	1929	19	17	34	6	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1930	478	1931	1930	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1931	372	1932	1931	19	17	34	7	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1932	300	1933	1932	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1933	376	1934	1933	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1934	376	1935	1934	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1935	300	1936	1935	19	17	34	23	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1936	290	1937	1936	19	17	34	8	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1937	316	1938	1937	19	17	34	4	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1938	329	1939	1938	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1939	275	1940	1939	19	17	34	46	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1940	290	1941	1940	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1941	316	1942	1941	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1942	300	1943	1942	19	17	34	89	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1943	376	1944	1943	19	17	34	11	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1944	477	1945	1944	19	17	34	1	\N	10	2018-05-11	\N	\N	ECB	\N	\N
1945	479	1946	1945	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1946	290	1947	1946	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1947	310	1948	1947	19	17	34	11	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1948	320	1949	1948	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1949	480	1950	1949	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1950	290	1951	1950	19	17	34	12	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1951	376	1952	1951	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1952	316	1953	1952	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1953	275	1954	1953	19	17	34	6	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1954	300	1955	1954	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1955	477	1956	1955	19	17	34	1	\N	10	2018-05-11	\N	\N	ECB	\N	\N
1956	290	1957	1956	19	17	34	5	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1957	275	1958	1957	19	17	34	15	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1958	316	1959	1958	19	17	34	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1959	310	1960	1959	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1960	316	1961	1960	19	17	34	8	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1961	376	1962	1961	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1962	275	1963	1962	19	17	34	11	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1963	300	1964	1963	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1964	290	1965	1964	19	17	34	6	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1965	275	1966	1965	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1966	316	1967	1966	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1967	300	1968	1967	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1968	290	1969	1968	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1969	397	1970	1969	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1970	316	1971	1970	19	17	34	3	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1971	327	1972	1971	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1972	334	1973	1972	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1973	290	1974	1973	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1974	310	1975	1974	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1975	316	1976	1975	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1976	316	1977	1976	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1977	481	1978	1977	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1978	300	1979	1978	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1979	300	1980	1979	19	17	34	8	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1980	329	1981	1980	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1981	316	1982	1981	19	17	34	7	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1982	303	1983	1982	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1983	310	1984	1983	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1984	477	1985	1984	19	17	34	1	\N	10	2018-05-11	\N	\N	ECB	\N	\N
1985	397	1986	1985	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1986	329	1987	1986	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1987	316	1988	1987	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1988	335	1989	1988	19	17	34	2	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1989	327	1990	1989	19	17	34	11	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1990	373	1991	1990	19	17	34	1	\N	10	2019-10-18	\N	\N	ECB	\N	\N
1991	290	1992	1992	19	17	36	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1992	372	1993	1993	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1993	250	1994	1994	19	17	36	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1994	347	1995	1995	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1995	263	1996	1996	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1996	372	1997	1997	19	17	36	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1997	290	1998	1998	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1998	303	1999	1999	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
1999	276	2000	2000	19	17	36	4	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2000	376	2001	2001	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2001	310	2002	2002	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2002	376	2003	2003	19	17	36	15	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2003	302	2004	2004	19	17	36	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2004	302	2005	2005	19	17	36	10	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2005	276	2006	2006	19	17	36	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2006	376	2007	2007	19	17	36	7	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2007	372	2008	2008	19	17	36	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2008	276	2009	2009	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2009	481	2010	2010	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2010	292	2011	2011	19	18	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2011	486	2012	2012	19	18	36	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2012	302	2013	2013	19	17	36	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2013	372	2014	2014	19	17	36	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2014	276	2015	2015	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2015	349	2016	2016	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2016	330	2017	2017	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2017	330	2018	2018	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2018	254	2019	2019	19	17	36	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2019	379	2020	2020	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2020	335	2021	2021	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2021	263	2022	2022	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2022	349	2023	2023	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2023	349	2024	2024	19	17	36	11	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2024	397	2025	2025	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2025	411	2026	2026	19	17	36	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2026	254	2027	2027	19	17	36	3	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2027	422	2028	2028	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2028	487	2029	2029	19	17	36	4	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2029	330	2030	2030	19	17	36	8	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2030	330	2031	2031	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2031	327	2032	2032	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2032	487	2033	2033	19	17	36	5	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2033	351	2034	2034	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2034	487	2035	2035	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2035	488	2036	2036	19	17	36	5	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2036	487	2037	2037	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2037	330	2038	2038	19	17	36	2	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2038	487	2039	2039	19	17	36	7	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2039	330	2040	2040	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2040	487	2041	2041	19	17	36	7	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2041	327	2042	2042	19	17	36	1	\N	10	2019-10-18	\N	\N	ECD	\N	\N
2042	249	2043	2042	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2043	246	2044	1842	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2044	250	2045	1841	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2045	249	2046	1842	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2046	247	2047	2042	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
2047	248	2048	1842	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: Person; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Person" (id_person, person_name, person_lastname, deleted_at) FROM stdin;
9		Mouglia V.	\N
10		DD Larrea	\N
11		F. Cuezzo	\N
12		PB Gervazoni	\N
13		Damborsky	\N
14		Achitte C.	\N
15		R.A.Buyatti	\N
16		Fernandez V.	\N
\.


--
-- Data for Name: PreservationMethod; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PreservationMethod" (id_preservation_method, method_name, deleted_at) FROM stdin;
4	Montado	\N
5	Alcohol	\N
6	Sin especificar	\N
\.


--
-- Data for Name: Province; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Province" (id_province, id_country, province_name, deleted_at) FROM stdin;
4	2	Chaco	\N
5	2	Corrientes	\N
6	2	Misiones	\N
\.


--
-- Data for Name: Rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Rol" (role_id, name, description, deleted_at) FROM stdin;
1	ADMIN	\N	\N
2	USER	\N	\N
3	RESEARCHER	\N	\N
\.


--
-- Data for Name: Service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Service" (id_service, service_name, deleted_at) FROM stdin;
1	test	\N
\.


--
-- Data for Name: Taxon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Taxon" (id_taxon, name, id_taxonomic_level, parent_id, id_author, description_year, deleted_at) FROM stdin;
245	Animalia	10	\N	\N	\N	\N
246	Formicidae	14	245	\N	\N	\N
247	Ectatomminae	15	246	\N	\N	\N
248	Ectatommini	16	247	\N	\N	\N
249	Ectatomma	17	248	\N	\N	\N
250	Ectatomma opaciventre	18	249	23	1861	\N
251	Formicinae	15	246	\N	\N	\N
252	Camponotini	16	251	\N	\N	\N
253	Camponotus	17	252	\N	\N	\N
254	Camponotus rufipes	18	253	24	1775	\N
255	Myrmicinae	15	246	\N	\N	\N
256	Attini	16	255	\N	\N	\N
257	Mycetophylax	17	256	\N	\N	\N
258	Mycetophylax simplex	18	257	25	1888	\N
259	Ponerinae	15	246	\N	\N	\N
260	Ponerini	16	259	\N	\N	\N
261	Leptogenys	17	260	\N	\N	\N
262	Leptogenys bohlsi	18	261	25	1896	\N
263	Ectatomma edentatum	18	249	23	1863	\N
264	Gnamptogenys	17	248	\N	\N	\N
265	Gnamptogenys triangularis	18	264	26	1887	\N
266	Cephalotes	17	256	\N	\N	\N
267	Cephalotes maculatus	18	266	27	1876	\N
268	Cephalotes clypeatus	18	266	24	1804	\N
269	Cyphomyrmex	17	256	\N	\N	\N
270	Cyphomyrmex transversus	18	269	25	1894	\N
271	Apterostigma	17	256	\N	\N	\N
272	Apterostigma pilosum	18	271	26	1865	\N
273	Plagiolepidini	16	251	\N	\N	\N
274	Nylanderia	17	273	\N	\N	\N
275	Nylanderia fulva	18	274	26	1862	\N
276	Nylanderia silvestrii	18	274	25	1906	\N
277	Dolichoderinae	15	246	\N	\N	\N
278	Dolichoderini	16	277	\N	\N	\N
279	Dolichoderus	17	278	\N	\N	\N
280	Dolichoderus bispinosus	18	279	28	1792	\N
281	Dolichoderus lamellosus	18	279	26	1870	\N
282	Dolichoderus germaini	18	279	25	1894	\N
283	Odontomachus	17	260	\N	\N	\N
284	Odontomachus haematodus	18	283	29	1758	\N
285	Amblyoponinae	15	246	\N	\N	\N
286	Amblyoponini	16	285	\N	\N	\N
287	Prionopelta	17	286	\N	\N	\N
288	Prionopelta punctulata	18	287	26	1866	\N
289	Hypoponera	17	260	\N	\N	\N
290	Hypoponera sp1	18	289	\N	\N	\N
291	Octostruma	17	256	\N	\N	\N
292	Octostruma balzani	18	291	25	1894	\N
293	Solenopsidini	16	255	\N	\N	\N
294	Solenopsis	17	293	\N	\N	\N
295	Solenopsis sp1	18	294	\N	\N	\N
296	Myrmelachistini	16	251	\N	\N	\N
297	Brachymyrmex	17	296	\N	\N	\N
298	Brachymyrmex sp1	18	297	\N	\N	\N
299	Wasmannia	17	256	\N	\N	\N
300	Wasmannia auropunctata	18	299	23	1863	\N
301	Strumigenys	17	256	\N	\N	\N
302	Strumigenys eggersi	18	301	25	1890	\N
303	Hypoponera sp2	18	289	\N	\N	\N
304	Rogeria	17	293	\N	\N	\N
305	Rogeria scobinata	18	304	30	1994	\N
306	Trachymyrmex	17	256	\N	\N	\N
307	Trachymyrmex sp1	18	306	\N	\N	\N
308	Leptogenys pusilla	18	261	25	1890	\N
309	Pheidole	17	256	\N	\N	\N
310	Pheidole sp1	18	309	\N	\N	\N
311	Strumigenys dyseides	18	301	31	2000	\N
312	Acromyrmex	17	256	\N	\N	\N
313	Acromyrmex cf. lundii	18	312	32	1838	\N
314	Strumigenys lilloana	18	301	33	1950	\N
315	Linepithema	17	278	\N	\N	\N
316	Linepithema humile	18	315	26	1868	\N
317	Anochetus	17	260	\N	\N	\N
318	Anochetus neglectus	18	317	25	1894	\N
319	Cyphomyrmex rimosus	18	269	34	1851	\N
320	Pheidole sp2	18	309	\N	\N	\N
321	Dorylinae	15	246	\N	\N	\N
322	Ecitonini	16	321	\N	\N	\N
323	Labidus 	17	322	\N	\N	\N
324	Labidus sp1	18	323	\N	\N	\N
325	Crematogastrini	16	255	\N	\N	\N
326	Nesomyrmex	17	325	\N	\N	\N
327	Nesomyrmex spininodis	18	326	26	1887	\N
328	Crematogaster	17	325	\N	\N	\N
329	Crematogaster sp1	18	328	\N	\N	\N
330	Cephalotes sp1	18	266	\N	\N	\N
331	Pseudomyrmecinae	15	246	\N	\N	\N
332	Pseudomyrmecini	16	331	\N	\N	\N
333	Pseudomyrmex	17	332	\N	\N	\N
334	Pseudomyrmex sp1	18	333	\N	\N	\N
335	Camponotus sp1	18	253	\N	\N	\N
336	Heteroponerinae	15	246	\N	\N	\N
337	Heteroponerini	16	336	\N	\N	\N
338	Acanthoponera	17	337	\N	\N	\N
339	Acanthoponera mucronata	18	338	23	1860	\N
340	Camponotus cf. substitutus	18	253	25	1894	\N
341	Pseudomyrmex sp2	18	333	\N	\N	\N
342	Cephalotes cf. incertus	18	266	25	1906	\N
343	Eciton	17	322	\N	\N	\N
344	Eciton sp1	18	343	\N	\N	\N
345	Nesomyrmex vicinus	18	326	26	1887	\N
346	Labidus praedator	18	323	35	1858	\N
347	Ectatomma brunneum	18	249	35	1858	\N
348	Pseudomyrmex sp3	18	333	\N	\N	\N
349	Camponotus cf. mus	18	253	23	1863	\N
350	Linepithema sp1	18	315	\N	\N	\N
351	Pseudomyrmex cf. gracilis	18	333	24	1804	\N
352	Cephalotes sp4	18	266	\N	\N	\N
353	Cephalotes sp2	18	266	\N	\N	\N
354	Procryptocerus	17	256	\N	\N	\N
355	Procryptocerus goeldii	18	354	36	1899	\N
356	Odontomachus chelifer	18	283	37	1802	\N
357	Gnamptogenys striatula	18	264	26	1884	\N
358	Cephalotes incertus	18	266	25	1906	\N
359	Cephalotes minutus	18	266	24	1804	\N
360	Cephalotes pilosus	18	266	25	1896	\N
361	Pseudomyrmex pallidus	18	333	35	1855	\N
362	Pseudomyrmex gracilis	18	333	24	1804	\N
363	Pseudomyrmex phyllophilus	18	333	35	1858	\N
364	Camponotus blandus	18	253	35	1858	\N
365	Camponotus cordiceps 	18	253	38	1939	\N
366	Camponotus punctulatus	18	253	26	1868	\N
367	Camponotus sericeiventris	18	253	32	1838	\N
368	Dorymyrmex	17	278	\N	\N	\N
369	Dorymyrmex thoracicus	18	368	39	1916	\N
370	Nylanderia sp3	18	274	\N	\N	\N
371	Pheidole cf. synarmata	18	309	40	2003	\N
372	Hypoponera sp4	18	289	\N	\N	\N
373	Gnamptogenys moelleri	18	264	36	1912	\N
374	Camponotus sp5	18	253	\N	\N	\N
375	Camponotus sp2	18	253	\N	\N	\N
376	Solenopsis sp2	18	294	\N	\N	\N
377	Dolichoderus sp1	18	279	\N	\N	\N
378	Neoponera	17	260	\N	\N	\N
379	Neoponera cf. villosa	18	378	24	1804	\N
380	Hypoponera schmalzi	18	289	25	1896	\N
381	Neoponera villosa	18	378	24	1804	\N
382	Cephalotes prodigiosus	18	266	38	1921	\N
383	Cephalotes bruchi	18	266	36	1912	\N
384	Strumigenys denticulata	18	301	26	1887	\N
385	Neivamyrmex	17	322	\N	\N	\N
386	Neivamyrmex carettei	18	385	36	1913	\N
387	Pseudomyrmex urbanus	18	333	35	1877	\N
388	Camponotus mus	18	253	23	1863	\N
389	Camponotus substitutus	18	253	25	1894	\N
390	Dorymyrmex pyramicus	18	368	23	1863	\N
391	Heteroponera	17	337	\N	\N	\N
392	Heteroponera mayri	18	391	41	1962	\N
393	Heteroponera dolo	18	391	23	1860	\N
394	Linepithema pulex	18	315	42	2007	\N
395	Neivamyrmex angustinodis	18	385	25	1888	\N
396	Brachymyrmex pilipes	18	297	26	1887	\N
397	Acromyrmex sp1	18	312	\N	\N	\N
398	Neoponera crenata	18	378	23	1861	\N
399	Hypoponera foreli	18	289	26	1887	\N
400	Odontomachus meinerti 	18	283	36	1905	\N
401	Pachycondyla	17	260	\N	\N	\N
402	Pachycondyla striata	18	401	35	1858	\N
403	Pogonomyrmecini	16	255	\N	\N	\N
404	Pogonomyrmex	17	403	\N	\N	\N
405	Pogonomyrmex naegelii	18	404	25	1878	\N
406	Pseudomyrmex cf. denticollis	18	333	25	1890	\N
407	Linepithema sp2	18	315	\N	\N	\N
408	Platythyreini	16	259	\N	\N	\N
409	Platythyrea	17	408	\N	\N	\N
410	Platythyrea exigua	18	409	41	1964	\N
411	Crematogaster sp2	18	328	\N	\N	\N
412	Megalomyrmex	17	293	\N	\N	\N
413	Megalomyrmex silvestrii	18	412	43	1909	\N
414	Strumigenys elongata	18	301	23	1863	\N
415	Brachymyrmex sp2	18	297	\N	\N	\N
416	Dorymyrmex sp1	18	368	\N	\N	\N
417	Cyphomyrmex sp1	18	269	\N	\N	\N
418	Pheidole radoszkowskii	18	309	26	1884	\N
419	Pheidole sp4	18	309	\N	\N	\N
420	Hypoponera sp3	18	289	\N	\N	\N
421	Procryptocerus cf. goeldii	18	354	36	1899	\N
422	Camponotus sp3	18	253	\N	\N	\N
423	Ectatomma sp1	18	249	\N	\N	\N
424	Eciton vagans	18	343	28	1792	\N
425	Strumigenys cf. eggersi	18	301	25	1890	\N
426	Anochetus cf. neglectus	18	317	25	1894	\N
427	Gnamptogenys sp1	18	264	\N	\N	\N
428	Nylanderia cf. silvestrii	18	274	25	1906	\N
429	Pseudomyrmicinae	15	246	\N	\N	\N
430	Pseudomirmicini	16	429	\N	\N	\N
431	Pseudomyrmex	17	430	\N	\N	\N
432	Pseudomyrmex sp1	18	431	\N	\N	\N
433	Myrmelachystini	16	251	\N	\N	\N
434	Brachymyrmex	17	433	\N	\N	\N
435	Brachymyrmex sp1	18	434	\N	\N	\N
436	Pheidole sp	18	309	\N	\N	\N
437	Nesomirmex	17	325	\N	\N	\N
438	Nesomirmex sp	18	437	\N	\N	\N
439	Amoimyrmex	17	256	\N	\N	\N
440	Amoimyrmex bruchy	18	439	\N	\N	\N
441	Apterostigma sp	18	271	\N	\N	\N
442	Ponrinae	15	246	\N	\N	\N
443	Ponerini	16	442	\N	\N	\N
444	Anochetus	17	443	\N	\N	\N
445	Anochetus sp	18	444	\N	\N	\N
446	Ectatominae	15	246	\N	\N	\N
447	Ectatomini	16	446	\N	\N	\N
448	Ponerocantha	17	447	\N	\N	\N
449	Ponerocantha sp	18	448	\N	\N	\N
450	Camponotus sp	18	253	\N	\N	\N
451	Brachymyrmex sp	18	434	\N	\N	\N
452	Leptomirmecini	16	277	\N	\N	\N
453	Dorymyrmex	17	452	\N	\N	\N
454	Dorymyrmex sp	18	453	\N	\N	\N
455	Camponotus sp4	18	253	\N	\N	\N
456	Cephalotes sp3	18	266	\N	\N	\N
457	Pseudomyrmex sp2	18	431	\N	\N	\N
458	Pachycondyla	17	443	\N	\N	\N
459	Pachycondyla sp	18	458	\N	\N	\N
460	Ectatomma sp	18	249	\N	\N	\N
461	Hypoponera	17	442	\N	\N	\N
462	Hypoponera sp	18	461	\N	\N	\N
463	Labidus	17	321	\N	\N	\N
464	Labidus sp	18	463	\N	\N	\N
465	Hypoponera trigona	18	289	26	1887	\N
466	Camponotus sp8	18	253	\N	\N	\N
467	Camponotus sp9	18	253	\N	\N	\N
468	Camponotus sp10	18	253	\N	\N	\N
469	Procryptocerus hylaeus	18	354	41	1951	\N
470	Camponotus sp11	18	253	\N	\N	\N
471	Camponotus sp12	18	253	\N	\N	\N
472	Camponotus sanctaefidei	18	253	44	1892	\N
473	Myrmelachistini	16	255	\N	\N	\N
474	Myrmelachista	17	473	\N	\N	\N
475	Myrmelachista sp1	18	474	\N	\N	\N
476	Strumigenys louisianae	18	301	23	1863	\N
477	Strumigenys cf. silvestrii	18	301	25	1906	\N
478	Pheidole cf. capillata	18	309	25	1906	\N
479	Acromyrmex sp2	18	312	\N	\N	\N
480	Acromyrmex sp3	18	312	\N	\N	\N
481	Pheidole sp3	18	309	\N	\N	\N
482	Nylanderia sp1	18	274	\N	\N	\N
483	Acromyrmex heyeri	18	312	36	1899	\N
484	Solenopsis	17	256	\N	\N	\N
485	Solenopsis sp1	18	484	\N	\N	\N
486	Gnamptogenys sulcata	18	264	35	1858	\N
487	Crematogaster sp3	18	328	\N	\N	\N
488	Dorymyrmex sp3	18	368	\N	\N	\N
\.


--
-- Data for Name: TaxonomicLevel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TaxonomicLevel" (id_taxonomic_level, name, deleted_at) FROM stdin;
10	Kingdom	\N
11	Phylum	\N
12	Class	\N
13	Order	\N
14	Family	\N
15	Subfamily	\N
16	Tribe	\N
17	Genus	\N
18	Species	\N
\.


--
-- Data for Name: Trap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Trap" (id_trap, trap_name, deleted_at) FROM stdin;
10	Pitfall	\N
11	Captura Manual	\N
12	Winkler	\N
13	Golpeteo de Follaje	\N
14	Aspirado	\N
15	Tamizado de hojarasca	\N
16	golpeteo de follaje	\N
17	Tamizado	\N
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (user_id, first_name, last_name, email, password, created_at, deleted_at, role_id) FROM stdin;
1	Admin	GEMA	admin@gema.com	$2b$12$6uOH5ldC1MpN1GF9Xh1zWuF6nqKdHpl0jW4PeaI3j58I14Ait129a	2025-11-10 15:58:29.081894+00	\N	1
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
2444ddc3-d899-41ce-a8e8-e74caa75ed7c	dfa4c9cebb56786f6816d423a4deb7526a67d0409aad7873ecbf8069e153afef	2025-11-10 15:49:36.549752+00	20251110154936_refactor_complete_model	\N	\N	2025-11-10 15:49:36.478641+00	1
ae488b8b-914f-4f16-83f1-88bffed4968f	7b5f3462d5d77d42da6e74f0e533abe8ffc3922dda1898fd90bcaf5d695674d9	2025-11-16 02:23:47.996715+00	20251116022347_add_confirmation_to_observation	\N	\N	2025-11-16 02:23:47.932636+00	1
\.


--
-- Name: Author_id_author_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Author_id_author_seq"', 44, true);


--
-- Name: Caste_id_caste_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Caste_id_caste_seq"', 31, true);


--
-- Name: ClimateData_id_climate_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ClimateData_id_climate_data_seq"', 36, true);


--
-- Name: Collection_id_collection_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Collection_id_collection_seq"', 2048, true);


--
-- Name: Contact_id_contact_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Contact_id_contact_seq"', 1, false);


--
-- Name: Country_id_country_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Country_id_country_seq"', 2, true);


--
-- Name: Department_id_department_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Department_id_department_seq"', 28, true);


--
-- Name: Environment_id_environment_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Environment_id_environment_seq"', 34, true);


--
-- Name: Geolocation_id_geolocation_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Geolocation_id_geolocation_seq"', 2042, true);


--
-- Name: Locality_id_locality_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Locality_id_locality_seq"', 42, true);


--
-- Name: Observation_id_observation_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Observation_id_observation_seq"', 2047, true);


--
-- Name: Person_id_person_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Person_id_person_seq"', 16, true);


--
-- Name: PreservationMethod_id_preservation_method_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PreservationMethod_id_preservation_method_seq"', 6, true);


--
-- Name: Province_id_province_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Province_id_province_seq"', 6, true);


--
-- Name: Rol_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Rol_role_id_seq"', 3, true);


--
-- Name: Service_id_service_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Service_id_service_seq"', 1, true);


--
-- Name: Taxon_id_taxon_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Taxon_id_taxon_seq"', 488, true);


--
-- Name: TaxonomicLevel_id_taxonomic_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TaxonomicLevel_id_taxonomic_level_seq"', 18, true);


--
-- Name: Trap_id_trap_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Trap_id_trap_seq"', 17, true);


--
-- Name: User_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_user_id_seq"', 1, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Author pk_author; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Author"
    ADD CONSTRAINT pk_author PRIMARY KEY (id_author);


--
-- Name: Caste pk_caste; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Caste"
    ADD CONSTRAINT pk_caste PRIMARY KEY (id_caste);


--
-- Name: ClimateData pk_climate_data; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClimateData"
    ADD CONSTRAINT pk_climate_data PRIMARY KEY (id_climate_data);


--
-- Name: Collection pk_collection; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Collection"
    ADD CONSTRAINT pk_collection PRIMARY KEY (id_collection);


--
-- Name: Contact pk_contact; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT pk_contact PRIMARY KEY (id_contact);


--
-- Name: Country pk_country; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Country"
    ADD CONSTRAINT pk_country PRIMARY KEY (id_country);


--
-- Name: Department pk_department; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT pk_department PRIMARY KEY (id_department);


--
-- Name: Environment pk_environment; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Environment"
    ADD CONSTRAINT pk_environment PRIMARY KEY (id_environment);


--
-- Name: Geolocation pk_geolocation; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Geolocation"
    ADD CONSTRAINT pk_geolocation PRIMARY KEY (id_geolocation);


--
-- Name: Locality pk_locality; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Locality"
    ADD CONSTRAINT pk_locality PRIMARY KEY (id_locality);


--
-- Name: Observation pk_observation; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Observation"
    ADD CONSTRAINT pk_observation PRIMARY KEY (id_observation);


--
-- Name: Person pk_person; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Person"
    ADD CONSTRAINT pk_person PRIMARY KEY (id_person);


--
-- Name: PreservationMethod pk_preservation_method; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PreservationMethod"
    ADD CONSTRAINT pk_preservation_method PRIMARY KEY (id_preservation_method);


--
-- Name: Province pk_province; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Province"
    ADD CONSTRAINT pk_province PRIMARY KEY (id_province);


--
-- Name: Rol pk_rol; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Rol"
    ADD CONSTRAINT pk_rol PRIMARY KEY (role_id);


--
-- Name: Service pk_service; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT pk_service PRIMARY KEY (id_service);


--
-- Name: Taxon pk_taxon; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Taxon"
    ADD CONSTRAINT pk_taxon PRIMARY KEY (id_taxon);


--
-- Name: TaxonomicLevel pk_taxonomic_level; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaxonomicLevel"
    ADD CONSTRAINT pk_taxonomic_level PRIMARY KEY (id_taxonomic_level);


--
-- Name: Trap pk_trap; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Trap"
    ADD CONSTRAINT pk_trap PRIMARY KEY (id_trap);


--
-- Name: User pk_user; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT pk_user PRIMARY KEY (user_id);


--
-- Name: TaxonomicLevel_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TaxonomicLevel_name_key" ON public."TaxonomicLevel" USING btree (name);


--
-- Name: unique_climate_data_locality_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX unique_climate_data_locality_date ON public."ClimateData" USING btree (id_locality, climate_date);


--
-- Name: uq_rol_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_rol_name ON public."Rol" USING btree (name);


--
-- Name: uq_user_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_user_email ON public."User" USING btree (email);


--
-- Name: ClimateData fk_climate_data_locality; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClimateData"
    ADD CONSTRAINT fk_climate_data_locality FOREIGN KEY (id_locality) REFERENCES public."Locality"(id_locality) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Collection fk_collection_person; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Collection"
    ADD CONSTRAINT fk_collection_person FOREIGN KEY (id_person) REFERENCES public."Person"(id_person) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Collection fk_collection_preservation_method; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Collection"
    ADD CONSTRAINT fk_collection_preservation_method FOREIGN KEY (id_preservation_method) REFERENCES public."PreservationMethod"(id_preservation_method) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Collection fk_collection_trap; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Collection"
    ADD CONSTRAINT fk_collection_trap FOREIGN KEY (id_trap) REFERENCES public."Trap"(id_trap) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Contact fk_contact_service; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT fk_contact_service FOREIGN KEY (id_service) REFERENCES public."Service"(id_service) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Department fk_department_province; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Department"
    ADD CONSTRAINT fk_department_province FOREIGN KEY (id_province) REFERENCES public."Province"(id_province) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Geolocation fk_geolocation_locality; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Geolocation"
    ADD CONSTRAINT fk_geolocation_locality FOREIGN KEY (id_locality) REFERENCES public."Locality"(id_locality) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Locality fk_locality_department; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Locality"
    ADD CONSTRAINT fk_locality_department FOREIGN KEY (id_department) REFERENCES public."Department"(id_department) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Observation fk_observation_caste; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Observation"
    ADD CONSTRAINT fk_observation_caste FOREIGN KEY (id_caste) REFERENCES public."Caste"(id_caste) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Observation fk_observation_climate_data; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Observation"
    ADD CONSTRAINT fk_observation_climate_data FOREIGN KEY (id_climate_data) REFERENCES public."ClimateData"(id_climate_data) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Observation fk_observation_collection; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Observation"
    ADD CONSTRAINT fk_observation_collection FOREIGN KEY (id_collection) REFERENCES public."Collection"(id_collection) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Observation fk_observation_confirmer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Observation"
    ADD CONSTRAINT fk_observation_confirmer FOREIGN KEY (id_confirmer) REFERENCES public."Person"(id_person) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Observation fk_observation_environment; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Observation"
    ADD CONSTRAINT fk_observation_environment FOREIGN KEY (id_environment) REFERENCES public."Environment"(id_environment) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Observation fk_observation_geolocation; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Observation"
    ADD CONSTRAINT fk_observation_geolocation FOREIGN KEY (id_geolocation) REFERENCES public."Geolocation"(id_geolocation) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Observation fk_observation_identifier; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Observation"
    ADD CONSTRAINT fk_observation_identifier FOREIGN KEY (id_identifier) REFERENCES public."Person"(id_person) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Observation fk_observation_taxon; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Observation"
    ADD CONSTRAINT fk_observation_taxon FOREIGN KEY (id_taxon) REFERENCES public."Taxon"(id_taxon) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Province fk_province_country; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Province"
    ADD CONSTRAINT fk_province_country FOREIGN KEY (id_country) REFERENCES public."Country"(id_country) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Taxon fk_taxon_author; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Taxon"
    ADD CONSTRAINT fk_taxon_author FOREIGN KEY (id_author) REFERENCES public."Author"(id_author) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Taxon fk_taxon_parent; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Taxon"
    ADD CONSTRAINT fk_taxon_parent FOREIGN KEY (parent_id) REFERENCES public."Taxon"(id_taxon) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Taxon fk_taxon_taxonomic_level; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Taxon"
    ADD CONSTRAINT fk_taxon_taxonomic_level FOREIGN KEY (id_taxonomic_level) REFERENCES public."TaxonomicLevel"(id_taxonomic_level) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User fk_user_rol; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT fk_user_rol FOREIGN KEY (role_id) REFERENCES public."Rol"(role_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict hmMJZokFZ1BJ54Ri9RFXh4ec1zTqqsQn3NPTxg4wZg3u0wrzy8T8hDJkT5TXJuc

